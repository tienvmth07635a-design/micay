package com.example.quanlyquanmicay.controller;

import com.example.quanlyquanmicay.model.Ban;
import com.example.quanlyquanmicay.repository.BanRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;

@WebServlet(name = "BanServlet", urlPatterns = {"/ban"})
public class BanServlet extends HttpServlet {
    private final BanRepository banRepository = new BanRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        String keyword = trimOrEmpty(request.getParameter("keyword"));
        String khuVuc = trimOrEmpty(request.getParameter("khuVuc"));
        if (khuVuc.isEmpty()) {
            khuVuc = "ALL";
        }

        String action = request.getParameter("action");

        // 1. Ấn nút "Đặt bàn" -> chuyển trạng thái sang "Có khách" và nhảy sang trang gọi món
        if ("dat-ban".equalsIgnoreCase(action)) {
            Integer id = parseIntOrNull(request.getParameter("id"));
            if (id != null) {
                try {
                    banRepository.capNhatTrangThai(id, "Có khách");
                } catch (Exception e) {
                    forwardWithError(request, response, keyword, khuVuc, "Không thể mở bàn gọi món, vui lòng thử lại.");
                    return;
                }
                // Đổi "/hoa-don" thành URL servlet trang gọi món của bạn nếu khác (VD: "/goi-mon" hoặc "/san-pham")
                response.sendRedirect(request.getContextPath() + "/goi-mon?maBan=" + id);
                return;
            }
            response.sendRedirect(request.getContextPath() + "/ban");
            return;
        }

        // 2. Đổi trạng thái bàn (Trống / Có khách / Khóa bàn)
        if ("status".equalsIgnoreCase(action)) {
            Integer id = parseIntOrNull(request.getParameter("id"));
            String trangThai = trimOrEmpty(request.getParameter("trangThai"));
            if (id != null && !trangThai.isEmpty()) {
                try {
                    banRepository.capNhatTrangThai(id, trangThai);
                } catch (Exception e) {
                    forwardWithError(request, response, keyword, khuVuc, "Không thể cập nhật trạng thái bàn, vui lòng thử lại.");
                    return;
                }
            }
            response.sendRedirect(request.getContextPath() + "/ban?khuVuc=" + encodeUrl(khuVuc) + "&keyword=" + encodeUrl(keyword));
            return;
        }

        loadListAttributes(request, keyword, khuVuc);
        request.getRequestDispatcher("/jsp/ban.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        String keyword = trimOrEmpty(request.getParameter("keyword"));
        String khuVucFilter = trimOrEmpty(request.getParameter("khuVuc"));
        if (khuVucFilter.isEmpty()) {
            khuVucFilter = "ALL";
        }

        String tenBan = trimOrEmpty(request.getParameter("txt_tenBan"));
        String khuVucMoi = trimOrEmpty(request.getParameter("sel_khuVuc"));
        String soGheStr = trimOrEmpty(request.getParameter("txt_soGhe"));
        String trangThai = trimOrEmpty(request.getParameter("sel_trangThai"));
        String hinhAnh = trimOrEmpty(request.getParameter("txt_hinhAnh"));

        if (tenBan.isEmpty()) {
            forwardWithError(request, response, keyword, khuVucFilter, "Vui lòng nhập tên bàn.");
            return;
        }

        int soGhe = 4;
        if (!soGheStr.isEmpty()) {
            try {
                soGhe = Integer.parseInt(soGheStr);
                if (soGhe <= 0) {
                    forwardWithError(request, response, keyword, khuVucFilter, "Số ghế phải lớn hơn 0.");
                    return;
                }
            } catch (NumberFormatException e) {
                forwardWithError(request, response, keyword, khuVucFilter, "Số ghế phải là số nguyên hợp lệ.");
                return;
            }
        }

        if (khuVucMoi.isEmpty()) {
            khuVucMoi = "Tầng 1";
        }
        if (trangThai.isEmpty()) {
            trangThai = "Trống";
        }
        if (hinhAnh.isEmpty()) {
            hinhAnh = "images/ban/ban-default.jpg";
        }

        Ban ban = new Ban();
        ban.setTenBan(tenBan);
        ban.setKhuVuc(khuVucMoi);
        ban.setSoGhe(soGhe);
        ban.setTrangThai(trangThai);
        ban.setHinhAnh(hinhAnh);

        try {
            banRepository.save(ban);
        } catch (Exception e) {
            forwardWithError(request, response, keyword, khuVucFilter, buildFriendlyErrorMessage(e));
            return;
        }

        response.sendRedirect(request.getContextPath() + "/ban");
    }

    private void loadListAttributes(HttpServletRequest request, String keyword, String khuVuc) {
        List<Ban> dsBan = banRepository.searchAndFilter(keyword, khuVuc);
        List<Ban> allBan = banRepository.findAll();

        long soBanTrong = allBan.stream().filter(b -> "Trống".equalsIgnoreCase(b.getTrangThai())).count();
        long soBanCoKhach = allBan.stream().filter(b -> "Có khách".equalsIgnoreCase(b.getTrangThai())).count();
        long soBanKhoa = allBan.stream().filter(b -> "Khóa bàn".equalsIgnoreCase(b.getTrangThai())).count();

        request.setAttribute("dsBan", dsBan);
        request.setAttribute("dsKhuVuc", banRepository.findDistinctKhuVuc());
        request.setAttribute("keyword", keyword);
        request.setAttribute("khuVuc", khuVuc);
        request.setAttribute("soBanTrong", soBanTrong);
        request.setAttribute("soBanCoKhach", soBanCoKhach);
        request.setAttribute("soBanKhoa", soBanKhoa);
        request.setAttribute("tongSoBan", allBan.size());
    }

    private void forwardWithError(HttpServletRequest request, HttpServletResponse response,
                                  String keyword, String khuVuc, String message)
            throws ServletException, IOException {
        request.setAttribute("errorMessage", message);
        loadListAttributes(request, keyword, khuVuc);
        request.getRequestDispatcher("/jsp/ban.jsp").forward(request, response);
    }

    private String buildFriendlyErrorMessage(Throwable e) {
        String raw = getAllMessages(e).toLowerCase();
        if (raw.contains("unique") || raw.contains("duplicate key") || raw.contains("uq_")) {
            return "Tên bàn này đã tồn tại trên hệ thống, vui lòng nhập tên khác.";
        }
        if (raw.contains("cannot insert the value null") || raw.contains("not-null")) {
            return "Còn thiếu thông tin bắt buộc, vui lòng kiểm tra lại các ô nhập.";
        }
        if (raw.contains("truncation") || raw.contains("too long") || raw.contains("string or binary data would be truncated")) {
            return "Nội dung nhập vượt quá độ dài cho phép, vui lòng rút ngắn lại.";
        }
        return "Không thể lưu bàn, vui lòng kiểm tra lại dữ liệu đã nhập.";
    }

    private String getAllMessages(Throwable t) {
        StringBuilder sb = new StringBuilder();
        Throwable cur = t;
        int depth = 0;
        while (cur != null && depth < 10) {
            if (cur.getMessage() != null) {
                sb.append(cur.getMessage()).append(" | ");
            }
            cur = cur.getCause();
            depth++;
        }
        return sb.toString();
    }

    private String trimOrEmpty(String s) {
        return s == null ? "" : s.trim();
    }

    private Integer parseIntOrNull(String val) {
        try {
            return (val == null || val.trim().isEmpty()) ? null : Integer.parseInt(val.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private String encodeUrl(String val) {
        try {
            return URLEncoder.encode(val == null ? "" : val, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return "";
        }
    }
}