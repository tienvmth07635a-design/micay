package com.example.quanlyquanmicay.repository;

import com.example.quanlyquanmicay.model.Ban;
import com.example.quanlyquanmicay.util.HibernateConfig;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.Collections;
import java.util.List;

public class BanRepository {

    public List<Ban> findAll() {
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            return session.createQuery("FROM Ban b ORDER BY b.maBan ASC", Ban.class)
                    .getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    public List<Ban> searchAndFilter(String keyword, String khuVuc) {
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            StringBuilder hql = new StringBuilder("FROM Ban b WHERE 1=1");
            boolean hasKeyword = keyword != null && !keyword.trim().isEmpty();
            boolean hasKhuVuc = khuVuc != null && !khuVuc.trim().isEmpty() && !"ALL".equalsIgnoreCase(khuVuc.trim());

            if (hasKeyword) {
                hql.append(" AND LOWER(b.tenBan) LIKE :kw");
            }
            if (hasKhuVuc) {
                hql.append(" AND b.khuVuc = :khuVuc");
            }
            hql.append(" ORDER BY b.maBan ASC");

            Query<Ban> query = session.createQuery(hql.toString(), Ban.class);
            if (hasKeyword) {
                query.setParameter("kw", "%" + keyword.trim().toLowerCase() + "%");
            }
            if (hasKhuVuc) {
                query.setParameter("khuVuc", khuVuc.trim());
            }
            return query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    public List<String> findDistinctKhuVuc() {
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            return session.createQuery(
                            "SELECT DISTINCT b.khuVuc FROM Ban b WHERE b.khuVuc IS NOT NULL ORDER BY b.khuVuc ASC",
                            String.class
                    )
                    .getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    public void save(Ban ban) {
        Transaction tx = null;
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            tx = session.beginTransaction();
            session.persist(ban);
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            throw e;
        }
    }

    public void capNhatTrangThai(Integer id, String trangThaiMoi) {
        if (id == null) return;
        Transaction tx = null;
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            tx = session.beginTransaction();
            Ban ban = session.get(Ban.class, id);
            if (ban != null) {
                ban.setTrangThai(trangThaiMoi);
                session.merge(ban);
            }
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            throw e;
        }
    }
}