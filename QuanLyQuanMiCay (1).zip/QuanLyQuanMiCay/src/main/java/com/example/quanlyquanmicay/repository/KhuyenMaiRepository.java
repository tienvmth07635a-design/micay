package com.example.quanlyquanmicay.repository;

import com.example.quanlyquanmicay.model.KhuyenMai;
import com.example.quanlyquanmicay.util.HibernateConfig;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.List;

public class KhuyenMaiRepository {
    private static final ZoneId VN_ZONE = ZoneId.of("Asia/Ho_Chi_Minh");

    public List<KhuyenMai> findDangHoatDong() {
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            LocalDateTime nowVN = LocalDateTime.now(VN_ZONE);
            return session.createQuery(
                            "FROM KhuyenMai km " +
                                    "WHERE km.trangThai = true AND km.ngayKetThuc >= :nowVN " +
                                    "ORDER BY km.maKhuyenMai DESC",
                            KhuyenMai.class
                    )
                    .setParameter("nowVN", nowVN)
                    .getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    public List<KhuyenMai> findDaKetThuc() {
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            LocalDateTime nowVN = LocalDateTime.now(VN_ZONE);
            return session.createQuery(
                            "FROM KhuyenMai km " +
                                    "WHERE km.trangThai = false OR km.ngayKetThuc < :nowVN " +
                                    "ORDER BY km.maKhuyenMai DESC",
                            KhuyenMai.class
                    )
                    .setParameter("nowVN", nowVN)
                    .getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    public void save(KhuyenMai km) {
        Transaction tx = null;
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            tx = session.beginTransaction();
            session.persist(km);
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            throw e;
        }
    }

    public void khoaKhuyenMai(Integer id) {
        if (id == null) return;
        Transaction tx = null;
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            tx = session.beginTransaction();
            KhuyenMai km = session.get(KhuyenMai.class, id);
            if (km != null) {
                km.setTrangThai(false);
                session.merge(km);
            }
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            throw e;
        }
    }
}