package com.example.quanlyquanmicay.controller;

import com.example.quanlyquanmicay.model.QuanLy;
import com.example.quanlyquanmicay.repository.QuanLyRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(name = "QuanLyServlet", urlPatterns = {"/quan-ly"})
public class QuanLyServlet extends HttpServlet {
    private final QuanLyRepository quanLyRepository = new QuanLyRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        request.setAttribute("dsQuanLy", quanLyRepository.findAll());
        request.getRequestDispatcher("/quan_ly.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        String tenQuanLy = request.getParameter("txt_tenQuanLy");
        String soDienThoai = request.getParameter("txt_soDienThoai");
        String trangThai = request.getParameter("sel_trangThai");

        if (tenQuanLy == null || tenQuanLy.trim().isEmpty()) {
            request.setAttribute("errorMessage", "Vui lòng nhập tên quản lý.");
            request.setAttribute("dsQuanLy", quanLyRepository.findAll());
            request.getRequestDispatcher("/quan_ly.jsp").forward(request, response);
            return;
        }

        QuanLy ql = new QuanLy();
        ql.setTenQuanLy(tenQuanLy.trim());
        ql.setSoDienThoai(soDienThoai != null ? soDienThoai.trim() : "");
        ql.setTrangThai((trangThai == null || trangThai.trim().isEmpty()) ? "Đang làm việc" : trangThai.trim());

        try {
            quanLyRepository.save(ql);
        } catch (Exception e) {
            request.setAttribute("errorMessage", "Không thể lưu quản lý, vui lòng kiểm tra lại dữ liệu.");
            request.setAttribute("dsQuanLy", quanLyRepository.findAll());
            request.getRequestDispatcher("/quan_ly.jsp").forward(request, response);
            return;
        }

        response.sendRedirect(request.getContextPath() + "/quan-ly");
    }
}