package com.example.quanlyquanmicay.repository;

import com.example.quanlyquanmicay.model.KhachHang;
import com.example.quanlyquanmicay.util.HibernateConfig;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Collections;
import java.util.List;

public class KhachHangRepository {

    public List<KhachHang> findAll() {
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            return session.createQuery("FROM KhachHang kh ORDER BY kh.maKhachHang DESC", KhachHang.class)
                    .getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    public List<KhachHang> searchByKeyword(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return findAll();
        }
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            String kw = "%" + keyword.trim().toLowerCase() + "%";
            return session.createQuery(
                            "FROM KhachHang kh " +
                                    "WHERE LOWER(kh.tenKhachHang) LIKE :kw OR kh.soDienThoai LIKE :kwRaw " +
                                    "ORDER BY kh.maKhachHang DESC",
                            KhachHang.class
                    )
                    .setParameter("kw", kw)
                    .setParameter("kwRaw", "%" + keyword.trim() + "%")
                    .getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    public void save(KhachHang khachHang) {
        Transaction tx = null;
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            tx = session.beginTransaction();
            session.persist(khachHang);
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            throw e;
        }
    }
}