package com.example.quanlyquanmicay.controller;

import com.example.quanlyquanmicay.model.KhachHang;
import com.example.quanlyquanmicay.repository.KhachHangRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(name = "KhachHangServlet", urlPatterns = {"/khach-hang"})
public class KhachHangServlet extends HttpServlet {
    private final KhachHangRepository khachHangRepository = new KhachHangRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        String keyword = request.getParameter("keyword");
        request.setAttribute("keyword", keyword != null ? keyword.trim() : "");
        request.setAttribute("dsKhachHang", khachHangRepository.searchByKeyword(keyword));
        request.getRequestDispatcher("/jsp/khach_hang.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        String tenKhachHang = request.getParameter("txt_tenKhachHang");
        String soDienThoai = request.getParameter("txt_soDienThoai");
        String diemStr = request.getParameter("txt_diemTichLuy");

        if (tenKhachHang == null || tenKhachHang.trim().isEmpty()) {
            forwardWithError(request, response, "Vui lòng nhập tên khách hàng.");
            return;
        }
        if (soDienThoai == null || soDienThoai.trim().isEmpty()) {
            forwardWithError(request, response, "Vui lòng nhập số điện thoại khách hàng.");
            return;
        }

        int diemTichLuy = 0;
        if (diemStr != null && !diemStr.trim().isEmpty()) {
            try {
                diemTichLuy = Integer.parseInt(diemStr.trim());
                if (diemTichLuy < 0) {
                    forwardWithError(request, response, "Điểm tích lũy không được nhỏ hơn 0.");
                    return;
                }
            } catch (NumberFormatException e) {
                forwardWithError(request, response, "Điểm tích lũy phải là số nguyên hợp lệ.");
                return;
            }
        }

        KhachHang kh = new KhachHang();
        kh.setTenKhachHang(tenKhachHang.trim());
        kh.setSoDienThoai(soDienThoai.trim());
        kh.setDiemTichLuy(diemTichLuy);

        try {
            khachHangRepository.save(kh);
        } catch (Exception e) {
            forwardWithError(request, response, buildFriendlyErrorMessage(e));
            return;
        }

        response.sendRedirect(request.getContextPath() + "/khach-hang");
    }

    private void forwardWithError(HttpServletRequest request, HttpServletResponse response, String message)
            throws ServletException, IOException {
        request.setAttribute("errorMessage", message);
        request.setAttribute("dsKhachHang", khachHangRepository.findAll());
        request.getRequestDispatcher("/jsp/khach_hang.jsp").forward(request, response);
    }

    private String buildFriendlyErrorMessage(Throwable e) {
        String raw = getAllMessages(e).toLowerCase();
        if (raw.contains("unique") || raw.contains("duplicate key") || raw.contains("uq_")) {
            return "Thông tin khách hàng (như số điện thoại) đã tồn tại trên hệ thống.";
        }
        if (raw.contains("cannot insert the value null") || raw.contains("not-null")) {
            return "Còn thiếu thông tin bắt buộc, vui lòng kiểm tra lại các ô nhập.";
        }
        if (raw.contains("truncation") || raw.contains("too long") || raw.contains("string or binary data would be truncated")) {
            return "Nội dung nhập vượt quá độ dài cho phép, vui lòng rút ngắn lại.";
        }
        return "Không thể lưu khách hàng, vui lòng kiểm tra lại dữ liệu đã nhập.";
    }

    private String getAllMessages(Throwable t) {
        StringBuilder sb = new StringBuilder();
        Throwable cur = t;
        int depth = 0;
        while (cur != null && depth < 10) {
            if (cur.getMessage() != null) {
                sb.append(cur.getMessage()).append(" | ");
            }
            cur = cur.getCause();
            depth++;
        }
        return sb.toString();
    }
}