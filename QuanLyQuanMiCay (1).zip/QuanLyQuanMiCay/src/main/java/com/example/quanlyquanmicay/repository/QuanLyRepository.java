package com.example.quanlyquanmicay.repository;

import com.example.quanlyquanmicay.model.QuanLy;
import com.example.quanlyquanmicay.util.HibernateConfig;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Collections;
import java.util.List;

public class QuanLyRepository {

    public List<QuanLy> findAll() {
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            return session.createQuery("FROM QuanLy ql ORDER BY ql.maQuanLy DESC", QuanLy.class)
                    .getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    public QuanLy findById(Integer id) {
        if (id == null) {
            return null;
        }
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            return session.get(QuanLy.class, id);
        }
    }

    public void save(QuanLy quanLy) {
        Transaction tx = null;
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            tx = session.beginTransaction();
            session.persist(quanLy);
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            throw e;
        }
    }
}