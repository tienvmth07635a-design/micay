package com.example.quanlyquanmicay.controller;

import com.example.quanlyquanmicay.model.KhuyenMai;
import com.example.quanlyquanmicay.repository.KhuyenMaiRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;

@WebServlet(name = "KhuyenMaiServlet", urlPatterns = {"/khuyen-mai"})
public class KhuyenMaiServlet extends HttpServlet {
    private static final ZoneId VN_ZONE = ZoneId.of("Asia/Ho_Chi_Minh");
    private final KhuyenMaiRepository khuyenMaiRepository = new KhuyenMaiRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        String tab = request.getParameter("tab");
        if (!"expired".equalsIgnoreCase(tab)) {
            tab = "active";
        }

        String action = request.getParameter("action");
        if ("lock".equalsIgnoreCase(action)) {
            Integer id = parseIntOrNull(request.getParameter("id"));
            if (id != null) {
                try {
                    khuyenMaiRepository.khoaKhuyenMai(id);
                } catch (Exception e) {
                    forwardWithError(request, response, tab, buildFriendlyErrorMessage(e));
                    return;
                }
            }
            response.sendRedirect(request.getContextPath() + "/khuyen-mai?tab=" + tab);
            return;
        }

        request.setAttribute("activeTab", tab);
        request.setAttribute("dsHoatDong", khuyenMaiRepository.findDangHoatDong());
        request.setAttribute("dsHetHan", khuyenMaiRepository.findDaKetThuc());
        request.getRequestDispatcher("/jsp/khuyen_mai.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        LocalDate todayVN = LocalDate.now(VN_ZONE);

        String maCode = trimOrEmpty(request.getParameter("txt_maCode"));
        String tenKhuyenMai = trimOrEmpty(request.getParameter("txt_tenKhuyenMai"));
        String loaiGiam = trimOrEmpty(request.getParameter("sel_loaiGiam"));
        if (loaiGiam.isEmpty()) {
            loaiGiam = "Phần trăm";
        }

        BigDecimal giaTriGiam = parseDecimal(request.getParameter("txt_giaTriGiam"), BigDecimal.ZERO);
        BigDecimal giamToiDa = parseDecimal(request.getParameter("txt_giamToiDa"), BigDecimal.ZERO);

        if (maCode.isEmpty()) {
            forwardWithError(request, response, "active", "Vui lòng nhập mã code khuyến mãi.");
            return;
        }
        if (tenKhuyenMai.isEmpty()) {
            forwardWithError(request, response, "active", "Vui lòng nhập tên chương trình khuyến mãi.");
            return;
        }
        if (giaTriGiam.compareTo(BigDecimal.ZERO) <= 0) {
            forwardWithError(request, response, "active", "Giá trị giảm phải lớn hơn 0.");
            return;
        }
        if ("Phần trăm".equalsIgnoreCase(loaiGiam) && giaTriGiam.compareTo(BigDecimal.valueOf(100)) > 0) {
            forwardWithError(request, response, "active", "Phần trăm giảm không được vượt quá 100%.");
            return;
        }
        if (giamToiDa.compareTo(BigDecimal.ZERO) < 0) {
            forwardWithError(request, response, "active", "Giảm tối đa không được nhỏ hơn 0.");
            return;
        }

        String ngayBatDauStr = request.getParameter("txt_ngayBatDau");
        String ngayKetThucStr = request.getParameter("txt_ngayKetThuc");
        if (isNullOrEmpty(ngayBatDauStr) || isNullOrEmpty(ngayKetThucStr)) {
            forwardWithError(request, response, "active", "Vui lòng chọn đầy đủ ngày bắt đầu và ngày kết thúc.");
            return;
        }

        LocalDate ngayBatDauDate;
        LocalDate ngayKetThucDate;
        try {
            ngayBatDauDate = LocalDate.parse(ngayBatDauStr.trim());
            ngayKetThucDate = LocalDate.parse(ngayKetThucStr.trim());
        } catch (DateTimeParseException e) {
            forwardWithError(request, response, "active", "Định dạng ngày không hợp lệ, vui lòng chọn lại.");
            return;
        }

        if (ngayBatDauDate.isBefore(todayVN)) {
            forwardWithError(request, response, "active", "Ngày bắt đầu không được chọn ngày quá khứ theo lịch Việt Nam.");
            return;
        }
        if (ngayKetThucDate.isBefore(ngayBatDauDate)) {
            forwardWithError(request, response, "active", "Ngày kết thúc phải từ ngày bắt đầu trở đi.");
            return;
        }

        // Nếu là loại Tiền mặt và không nhập giảm tối đa, mặc định giảm tối đa bằng giá trị giảm
        if ("Tiền mặt".equalsIgnoreCase(loaiGiam) && giamToiDa.compareTo(BigDecimal.ZERO) == 0) {
            giamToiDa = giaTriGiam;
        }

        KhuyenMai km = new KhuyenMai();
        km.setMaCode(maCode);
        km.setTenKhuyenMai(tenKhuyenMai);
        km.setLoaiGiam(loaiGiam);
        km.setGiaTriGiam(giaTriGiam);
        km.setGiamToiDa(giamToiDa);
        km.setNgayBatDau(LocalDateTime.of(ngayBatDauDate, LocalTime.of(0, 0, 0)));
        km.setNgayKetThuc(LocalDateTime.of(ngayKetThucDate, LocalTime.of(23, 59, 59)));

        String trangThaiParam = trimOrEmpty(request.getParameter("sel_trangThai"));
        LocalDateTime nowVN = LocalDateTime.now(VN_ZONE);
        boolean hoatDong = !"Hết hạn".equalsIgnoreCase(trangThaiParam) && !km.getNgayKetThuc().isBefore(nowVN);
        km.setTrangThai(hoatDong);

        try {
            khuyenMaiRepository.save(km);
        } catch (Exception e) {
            forwardWithError(request, response, "active", buildFriendlyErrorMessage(e));
            return;
        }

        String redirectTab = hoatDong ? "active" : "expired";
        response.sendRedirect(request.getContextPath() + "/khuyen-mai?tab=" + redirectTab);
    }

    private void forwardWithError(HttpServletRequest request, HttpServletResponse response, String tab, String message)
            throws ServletException, IOException {
        request.setAttribute("errorMessage", message);
        request.setAttribute("activeTab", tab);
        request.setAttribute("dsHoatDong", khuyenMaiRepository.findDangHoatDong());
        request.setAttribute("dsHetHan", khuyenMaiRepository.findDaKetThuc());
        request.getRequestDispatcher("/jsp/khuyen_mai.jsp").forward(request, response);
    }

    private String buildFriendlyErrorMessage(Throwable e) {
        String raw = getAllMessages(e).toLowerCase();

        if (raw.contains("unique") || raw.contains("duplicate key") || raw.contains("uq_")) {
            return "Mã code khuyến mãi này đã tồn tại trên hệ thống, vui lòng nhập mã khác.";
        }
        if (raw.contains("cannot insert the value null") || raw.contains("not-null")) {
            return "Còn thiếu thông tin bắt buộc, vui lòng kiểm tra lại các ô nhập.";
        }
        if (raw.contains("truncation") || raw.contains("too long") || raw.contains("string or binary data would be truncated")) {
            return "Nội dung nhập vượt quá độ dài cho phép, vui lòng rút ngắn lại.";
        }
        if (raw.contains("arithmetic overflow") || raw.contains("out of range")) {
            return "Giá trị số nhập vào vượt quá giới hạn cho phép (tối đa 12 chữ số, 2 số lẻ).";
        }
        if (raw.contains("connection") || raw.contains("communications link") || raw.contains("jdbc")) {
            return "Không kết nối được tới cơ sở dữ liệu, vui lòng thử lại sau.";
        }

        return "Không thể lưu khuyến mãi, vui lòng kiểm tra lại thông tin đã nhập.";
    }

    private String getAllMessages(Throwable t) {
        StringBuilder sb = new StringBuilder();
        Throwable cur = t;
        int depth = 0;
        while (cur != null && depth < 10) {
            if (cur.getMessage() != null) {
                sb.append(cur.getMessage()).append(" | ");
            }
            cur = cur.getCause();
            depth++;
        }
        return sb.toString();
    }

    private boolean isNullOrEmpty(String val) {
        return val == null || val.trim().isEmpty();
    }

    private String trimOrEmpty(String val) {
        return val == null ? "" : val.trim();
    }

    private BigDecimal parseDecimal(String val, BigDecimal defaultVal) {
        try {
            return isNullOrEmpty(val) ? defaultVal : new BigDecimal(val.trim());
        } catch (NumberFormatException e) {
            return defaultVal;
        }
    }

    private Integer parseIntOrNull(String val) {
        try {
            return isNullOrEmpty(val) ? null : Integer.parseInt(val.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}