<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Khuyến Mãi - Quán Mì Cay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <style>
        .promo-table {
            table-layout: fixed;
            width: 100%;
        }
        .promo-table th,
        .promo-table td {
            vertical-align: middle;
            word-wrap: break-word;
        }
    </style>
</head>
<body>
<div class="app-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div>
            <div class="sidebar-brand">
                <span>🍜</span>
                <span>Mì Cay Seoul 7 Cấp</span>
            </div>

            <div class="sidebar-admin">
                <span class="admin-avatar">Q</span>
                <div>
                    <div class="fw-semibold small">Quản Lý Cửa Hàng</div>
                    <div class="text-white-50" style="font-size: 0.72rem;">Admin</div>
                </div>
            </div>

            <div class="sidebar-group-title">Tổng quan &amp; Bán hàng</div>
            <ul class="sidebar-menu">
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/HomeServlet"><span>🏠</span><span>Trang chủ</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/ban"><span>🍽️</span><span>Bàn</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/san-pham"><span>🍜</span><span>Sản phẩm</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/hoa-don"><span>🧾</span><span>Hóa đơn</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/hoa-don-chi-tiet"><span>📋</span><span>Chi tiết hóa đơn</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/khach-hang"><span>🙋</span><span>Khách hàng</span></a></li>
            </ul>

            <div class="sidebar-group-title">Ưu đãi, Nhân sự &amp; Hệ thống</div>
            <ul class="sidebar-menu">
                <li><a class="sidebar-link active" href="${pageContext.request.contextPath}/khuyen-mai"><span>🏷️</span><span>Khuyến mãi</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/voucher"><span>🎟️</span><span>Voucher</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/nhan-vien"><span>👨‍🍳</span><span>Nhân viên</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/quan-ly"><span>👔</span><span>Quản lý</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/nhat-ki"><span>🕒</span><span>Nhật ký hoạt động</span></a></li>
            </ul>
        </div>

        <div class="sidebar-footer">
            <a class="sidebar-link mb-0" href="${pageContext.request.contextPath}/home"><span>↪</span><span>Đăng xuất</span></a>
        </div>
    </aside>

    <!-- Nội dung chính -->
    <div class="main-content">
        <header class="topbar">
            <h1 class="topbar-title">Quản Lý Khuyến Mãi</h1>
            <div class="d-flex align-items-center gap-2">
                <span class="text-muted small">Xin chào, Admin</span>
                <span class="user-badge">A</span>
            </div>
        </header>

        <main class="content-container">
            <c:if test="${not empty errorMessage}">
                <div class="alert alert-danger py-2" role="alert">
                        ${errorMessage}
                </div>
            </c:if>

            <!-- Form thêm Khuyến mãi -->
            <section class="section-panel mb-4">
                <h2 class="h6 fw-bold mb-3">Thêm Khuyến mãi mới &amp; Đặt thời gian</h2>

                <form id="frm_themKhuyenMai" method="post" action="${pageContext.request.contextPath}/khuyen-mai" novalidate>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label for="txt_maCode" class="form-label small fw-semibold">Mã code <span class="text-danger">*</span></label>
                            <input type="text" id="txt_maCode" name="txt_maCode" class="form-control form-control-sm" placeholder="VD: KM_MICAY15">
                            <div class="invalid-feedback">Vui lòng nhập mã code khuyến mãi.</div>
                        </div>

                        <div class="col-md-8">
                            <label for="txt_tenKhuyenMai" class="form-label small fw-semibold">Tên chương trình khuyến mãi <span class="text-danger">*</span></label>
                            <input type="text" id="txt_tenKhuyenMai" name="txt_tenKhuyenMai" class="form-control form-control-sm" placeholder="VD: Giảm 15% cho hóa đơn mì cay cấp độ">
                            <div class="invalid-feedback">Vui lòng nhập tên chương trình khuyến mãi.</div>
                        </div>

                        <div class="col-md-3">
                            <label for="sel_loaiGiam" class="form-label small fw-semibold">Loại giảm</label>
                            <select id="sel_loaiGiam" name="sel_loaiGiam" class="form-select form-select-sm" onchange="updateDiscountUnit()">
                                <option value="Phần trăm">Phần trăm (%)</option>
                                <option value="Tiền mặt">Tiền mặt (đ)</option>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label for="txt_giaTriGiam" class="form-label small fw-semibold">Giá trị giảm <span class="text-danger">*</span></label>
                            <div class="input-group input-group-sm">
                                <input type="number" step="any" min="0.01" id="txt_giaTriGiam" name="txt_giaTriGiam"
                                       class="form-control" placeholder="VD: 15">
                                <span class="input-group-text" id="unit_giaTriGiam">%</span>
                            </div>
                            <div class="invalid-feedback" id="err_giaTriGiam">Giá trị giảm phải lớn hơn 0.</div>
                        </div>

                        <div class="col-md-3">
                            <label for="txt_giamToiDa" class="form-label small fw-semibold">Giảm tối đa (đ)</label>
                            <input type="number" step="100" min="0" id="txt_giamToiDa" name="txt_giamToiDa"
                                   class="form-control form-control-sm" value="0">
                            <div class="invalid-feedback">Giảm tối đa phải từ 0 trở lên.</div>
                        </div>

                        <div class="col-md-3">
                            <label for="sel_trangThai" class="form-label small fw-semibold">Trạng thái</label>
                            <select id="sel_trangThai" name="sel_trangThai" class="form-select form-select-sm">
                                <option value="Đang áp dụng">Đang áp dụng</option>
                                <option value="Hết hạn">Hết hạn</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label for="txt_ngayBatDau" class="form-label small fw-semibold">Ngày bắt đầu <span class="text-danger">*</span></label>
                            <input type="date" id="txt_ngayBatDau" name="txt_ngayBatDau" class="form-control form-control-sm">
                            <div class="invalid-feedback" id="err_ngayBatDau">Vui lòng chọn ngày bắt đầu từ hôm nay trở đi.</div>
                        </div>

                        <div class="col-md-4">
                            <label for="txt_ngayKetThuc" class="form-label small fw-semibold">Ngày kết thúc <span class="text-danger">*</span></label>
                            <input type="date" id="txt_ngayKetThuc" name="txt_ngayKetThuc" class="form-control form-control-sm">
                            <div class="invalid-feedback" id="err_ngayKetThuc">Ngày kết thúc phải từ ngày bắt đầu trở đi.</div>
                        </div>

                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" id="btn_themKhuyenMai" class="btn btn-sm btn-order-blue w-100 py-2">
                                + Thêm Khuyến mãi
                            </button>
                        </div>
                    </div>
                </form>
            </section>

            <!-- 2 tab đồng bộ 1 khung bảng duy nhất -->
            <section class="section-panel">
                <ul class="nav nav-tabs mb-3" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link ${activeTab == 'active' ? 'active fw-bold' : ''}"
                           href="${pageContext.request.contextPath}/khuyen-mai?tab=active">
                            Đang áp dụng
                            <span class="badge bg-success ms-1">${dsHoatDong != null ? dsHoatDong.size() : 0}</span>
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link ${activeTab == 'expired' ? 'active fw-bold' : ''}"
                           href="${pageContext.request.contextPath}/khuyen-mai?tab=expired">
                            Đã kết thúc / Khóa
                            <span class="badge bg-secondary ms-1">${dsHetHan != null ? dsHetHan.size() : 0}</span>
                        </a>
                    </li>
                </ul>

                <c:set var="hienThiList" value="${activeTab == 'expired' ? dsHetHan : dsHoatDong}"/>

                <div class="table-responsive">
                    <table class="table table-hover promo-table mb-0">
                        <thead class="table-light">
                        <tr>
                            <th style="width: 7%;">ID</th>
                            <th style="width: 12%;">Mã code</th>
                            <th style="width: 22%;">Tên khuyến mãi</th>
                            <th style="width: 10%;">Loại giảm</th>
                            <th style="width: 12%;">Giá trị giảm</th>
                            <th style="width: 12%;">Giảm tối đa</th>
                            <th style="width: 8%;">Bắt đầu</th>
                            <th style="width: 8%;">Kết thúc</th>
                            <th style="width: 9%;" class="text-end">Thao tác</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:forEach var="km" items="${hienThiList}">
                            <tr>
                                <td class="fw-semibold">#${km.maKhuyenMai}</td>
                                <td><span class="badge bg-light text-dark border">${km.maCode}</span></td>
                                <td>${km.tenKhuyenMai}</td>
                                <td>${km.loaiGiam}</td>
                                <td class="fw-semibold text-primary">
                                    <c:choose>
                                        <c:when test="${km.loaiGiam == 'Phần trăm'}">
                                            <fmt:formatNumber value="${km.giaTriGiam}" pattern="#,##0.##"/>%
                                        </c:when>
                                        <c:otherwise>
                                            <fmt:formatNumber value="${km.giaTriGiam}" pattern="#,##0"/>đ
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td><fmt:formatNumber value="${km.giamToiDa}" pattern="#,##0"/>đ</td>
                                <td>${km.ngayBatDau != null ? km.ngayBatDau.toLocalDate() : ''}</td>
                                <td>${km.ngayKetThuc != null ? km.ngayKetThuc.toLocalDate() : ''}</td>
                                <td class="text-end">
                                    <c:choose>
                                        <c:when test="${activeTab == 'active'}">
                                            <a href="${pageContext.request.contextPath}/khuyen-mai?action=lock&id=${km.maKhuyenMai}&tab=active"
                                               class="btn btn-sm btn-pay-red"
                                               onclick="return confirm('Khóa và chuyển khuyến mãi ${km.maCode} sang đã kết thúc?');">
                                                🔒 Khóa
                                            </a>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge bg-danger">Kết thúc</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                            </tr>
                        </c:forEach>

                        <c:if test="${empty hienThiList}">
                            <tr>
                                <td colspan="9" class="text-center text-muted py-4">
                                    Không có khuyến mãi nào trong mục này.
                                </td>
                            </tr>
                        </c:if>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>
</div>

<script>
    function getVietnamTodayISO() {
        const parts = new Intl.DateTimeFormat("en-CA", {
            timeZone: "Asia/Ho_Chi_Minh",
            year: "numeric",
            month: "2-digit",
            day: "2-digit"
        }).formatToParts(new Date());

        const year = parts.find(p => p.type === "year").value;
        const month = parts.find(p => p.type === "month").value;
        const day = parts.find(p => p.type === "day").value;
        return `${year}-${month}-${day}`;
    }

    function syncDateConstraints() {
        const todayVN = getVietnamTodayISO();
        const startEl = document.getElementById("txt_ngayBatDau");
        const endEl = document.getElementById("txt_ngayKetThuc");
        const errStart = document.getElementById("err_ngayBatDau");
        const errEnd = document.getElementById("err_ngayKetThuc");

        if (startEl) {
            startEl.setAttribute("min", todayVN);
            if (startEl.value && startEl.value < todayVN) {
                startEl.value = todayVN;
                startEl.classList.add("is-invalid");
                if (errStart) {
                    errStart.textContent = "Không thể chọn ngày quá khứ theo lịch Việt Nam (đã đặt về hôm nay).";
                }
            } else {
                startEl.classList.remove("is-invalid");
            }
        }

        if (endEl) {
            const minEnd = (startEl && startEl.value) ? startEl.value : todayVN;
            endEl.setAttribute("min", minEnd);
            if (endEl.value && endEl.value < minEnd) {
                endEl.value = minEnd;
                endEl.classList.add("is-invalid");
                if (errEnd) {
                    errEnd.textContent = "Ngày kết thúc không được nhỏ hơn ngày bắt đầu.";
                }
            } else {
                endEl.classList.remove("is-invalid");
            }
        }
    }

    function updateDiscountUnit() {
        const loai = document.getElementById("sel_loaiGiam").value;
        const unit = document.getElementById("unit_giaTriGiam");
        const input = document.getElementById("txt_giaTriGiam");
        const err = document.getElementById("err_giaTriGiam");

        if (loai === "Phần trăm") {
            unit.textContent = "%";
            input.placeholder = "VD: 15";
            input.max = "100";
            err.textContent = "Phần trăm giảm phải từ 1 đến 100.";
        } else {
            unit.textContent = "đ";
            input.placeholder = "VD: 20000";
            input.removeAttribute("max");
            err.textContent = "Giá trị giảm phải lớn hơn 0.";
        }
    }

    function validateKhuyenMaiForm() {
        syncDateConstraints();
        let isValid = true;

        const loai = document.getElementById("sel_loaiGiam").value;
        const maCode = document.getElementById("txt_maCode");
        const tenKM = document.getElementById("txt_tenKhuyenMai");
        const giaTri = document.getElementById("txt_giaTriGiam");
        const giamToiDa = document.getElementById("txt_giamToiDa");
        const startEl = document.getElementById("txt_ngayBatDau");
        const endEl = document.getElementById("txt_ngayKetThuc");

        const valGiaTri = Number(giaTri.value);
        const giaTriOk = loai === "Phần trăm"
            ? (valGiaTri > 0 && valGiaTri <= 100)
            : (valGiaTri > 0);

        const todayVN = getVietnamTodayISO();
        const startOk = Boolean(startEl.value) && startEl.value >= todayVN;
        const endOk = Boolean(endEl.value) && (!startEl.value || endEl.value >= startEl.value);

        const checks = [
            { el: maCode, ok: maCode.value.trim().length > 0 },
            { el: tenKM, ok: tenKM.value.trim().length > 0 },
            { el: giaTri, ok: giaTriOk },
            { el: giamToiDa, ok: giamToiDa.value.trim() === "" || Number(giamToiDa.value) >= 0 },
            { el: startEl, ok: startOk },
            { el: endEl, ok: endOk }
        ];

        checks.forEach(({ el, ok }) => {
            if (!ok) {
                el.classList.add("is-invalid");
                isValid = false;
            } else {
                el.classList.remove("is-invalid");
            }
        });

        return isValid;
    }

    document.getElementById("frm_themKhuyenMai").addEventListener("submit", function (event) {
        if (!validateKhuyenMaiForm()) {
            event.preventDefault();
        }
    });

    const startInput = document.getElementById("txt_ngayBatDau");
    const endInput = document.getElementById("txt_ngayKetThuc");
    if (startInput) {
        startInput.addEventListener("change", syncDateConstraints);
        startInput.addEventListener("input", syncDateConstraints);
    }
    if (endInput) {
        endInput.addEventListener("change", syncDateConstraints);
        endInput.addEventListener("input", syncDateConstraints);
    }

    syncDateConstraints();
    updateDiscountUnit();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>