<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Khách Hàng - Quán Mì Cay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<div class="app-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div>
            <div class="sidebar-brand">
                <span>🍜</span>
                <span>Mì Cay Seoul 7 Cấp</span>
            </div>

            <div class="sidebar-admin">
                <span class="admin-avatar">Q</span>
                <div>
                    <div class="fw-semibold small">Quản Lý Cửa Hàng</div>
                    <div class="text-white-50" style="font-size: 0.72rem;">Admin</div>
                </div>
            </div>

            <div class="sidebar-group-title">Tổng quan &amp; Bán hàng</div>
            <ul class="sidebar-menu">
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/HomeServlet"><span>🏠</span><span>Trang chủ</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/ban"><span>🍽️</span><span>Bàn</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/san-pham"><span>🍜</span><span>Sản phẩm</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/hoa-don"><span>🧾</span><span>Hóa đơn</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/hoa-don-chi-tiet"><span>📋</span><span>Chi tiết hóa đơn</span></a></li>
                <li><a class="sidebar-link active" href="${pageContext.request.contextPath}/khach-hang"><span>🙋</span><span>Khách hàng</span></a></li>
            </ul>

            <div class="sidebar-group-title">Ưu đãi, Nhân sự &amp; Hệ thống</div>
            <ul class="sidebar-menu">
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/khuyen-mai"><span>🏷️</span><span>Khuyến mãi</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/voucher"><span>🎟️</span><span>Voucher</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/nhan-vien"><span>👨‍🍳</span><span>Nhân viên</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/quan-ly"><span>👔</span><span>Quản lý</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/nhat-ki"><span>🕒</span><span>Nhật ký hoạt động</span></a></li>
            </ul>
        </div>

        <div class="sidebar-footer">
            <a class="sidebar-link mb-0" href="${pageContext.request.contextPath}/HomeServlet"><span>↪</span><span>Đăng xuất</span></a>
        </div>
    </aside>

    <!-- Nội dung chính -->
    <div class="main-content">
        <header class="topbar">
            <h1 class="topbar-title">Quản Lý Khách Hàng</h1>
            <div class="d-flex align-items-center gap-2">
                <span class="text-muted small">Xin chào, Admin</span>
                <span class="user-badge">A</span>
            </div>
        </header>

        <main class="content-container">
            <c:if test="${not empty errorMessage}">
                <div class="alert alert-danger py-2" role="alert">
                    <c:out value="${errorMessage}"/>
                </div>
            </c:if>

            <!-- Form thêm khách hàng -->
            <section class="section-panel mb-4">
                <h2 class="h6 fw-bold mb-3">Thêm Khách hàng mới</h2>

                <form method="post" action="${pageContext.request.contextPath}/khach-hang" class="row g-3">
                    <div class="col-md-4">
                        <label for="txt_tenKhachHang" class="form-label small fw-semibold">Tên khách hàng <span class="text-danger">*</span></label>
                        <input type="text" id="txt_tenKhachHang" name="txt_tenKhachHang"
                               class="form-control form-control-sm"
                               placeholder="VD: Nguyễn Văn A"
                               value="<c:out value='${param.txt_tenKhachHang}'/>">
                    </div>

                    <div class="col-md-4">
                        <label for="txt_soDienThoai" class="form-label small fw-semibold">Số điện thoại <span class="text-danger">*</span></label>
                        <input type="text" id="txt_soDienThoai" name="txt_soDienThoai"
                               class="form-control form-control-sm"
                               placeholder="VD: 0912345678"
                               value="<c:out value='${param.txt_soDienThoai}'/>">
                    </div>

                    <div class="col-md-2">
                        <label for="txt_diemTichLuy" class="form-label small fw-semibold">Điểm tích lũy</label>
                        <input type="number" min="0" id="txt_diemTichLuy" name="txt_diemTichLuy"
                               class="form-control form-control-sm"
                               value="${not empty param.txt_diemTichLuy ? param.txt_diemTichLuy : '0'}">
                    </div>

                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-sm btn-order-blue w-100 py-2">
                            + Thêm Khách hàng
                        </button>
                    </div>
                </form>
            </section>

            <!-- Tìm kiếm & danh sách khách hàng -->
            <section class="section-panel">
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                    <h2 class="h6 fw-bold mb-0">Danh sách Khách hàng</h2>
                    <form method="get" action="${pageContext.request.contextPath}/khach-hang" class="d-flex gap-2">
                        <input type="text" name="keyword" class="form-control form-control-sm"
                               placeholder="Tìm tên hoặc SĐT..." value="<c:out value='${keyword}'/>">
                        <button type="submit" class="btn btn-sm btn-secondary">Tìm</button>
                        <c:if test="${not empty keyword}">
                            <a href="${pageContext.request.contextPath}/khach-hang" class="btn btn-sm btn-outline-secondary">Xóa lọc</a>
                        </c:if>
                    </form>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                        <tr>
                            <th style="width: 10%;">ID</th>
                            <th style="width: 35%;">Tên khách hàng</th>
                            <th style="width: 25%;">Số điện thoại</th>
                            <th style="width: 30%;" class="text-end">Điểm tích lũy</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:forEach var="kh" items="${dsKhachHang}">
                            <tr>
                                <td class="fw-semibold">#${kh.maKhachHang}</td>
                                <td><c:out value="${kh.tenKhachHang}"/></td>
                                <td><c:out value="${kh.soDienThoai}"/></td>
                                <td class="text-end fw-semibold text-primary">
                                    <fmt:formatNumber value="${kh.diemTichLuy != null ? kh.diemTichLuy : 0}" pattern="#,##0"/> điểm
                                </td>
                            </tr>
                        </c:forEach>
                        <c:if test="${empty dsKhachHang}">
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">
                                    Chưa có dữ liệu khách hàng phù hợp.
                                </td>
                            </tr>
                        </c:if>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>