<%--
  Created by IntelliJ IDEA.
  User: PC
  Date: 20/11/2026
  Time: 6:03 CH
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>

</body>
</html>
