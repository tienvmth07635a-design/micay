<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gọi Món - Mì Cay Seoul 7 Cấp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
            padding-bottom: 92px;
        }
        .order-shell {
            max-width: 760px;
            margin: 0 auto;
            background: #f8f9fa;
            min-height: 100vh;
        }
        .sticky-top-bar {
            position: sticky;
            top: 0;
            z-index: 1020;
            background: #ffffff;
            border-bottom: 1px solid #eceff3;
        }
        .circle-icon-btn {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            border: 1px solid #e9ecef;
            background: #f8f9fa;
            color: #1e293b;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            font-weight: 600;
        }
        .search-pill {
            background: #f1f3f5;
            border-radius: 10px;
            padding: 6px 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .search-pill input {
            border: none;
            background: transparent;
            outline: none;
            width: 100%;
            font-size: 0.92rem;
        }
        .cat-tabs {
            display: flex;
            overflow-x: auto;
            gap: 20px;
            padding: 10px 16px 0 16px;
            scrollbar-width: none;
        }
        .cat-tabs::-webkit-scrollbar {
            display: none;
        }
        .cat-tab {
            white-space: nowrap;
            text-decoration: none;
            color: #334155;
            font-weight: 700;
            font-size: 0.85rem;
            padding-bottom: 10px;
            border-bottom: 2.5px solid transparent;
            text-transform: uppercase;
        }
        .cat-tab.active, .cat-tab:hover {
            color: #f59e0b;
            border-bottom-color: #f59e0b;
        }
        .section-heading {
            font-size: 0.95rem;
            font-weight: 800;
            color: #1e293b;
            text-transform: uppercase;
            margin: 18px 0 10px 0;
        }
        .food-card {
            background: #ffffff;
            border-radius: 14px;
            padding: 12px;
            margin-bottom: 12px;
            box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
        }
        .food-thumb {
            width: 76px;
            height: 76px;
            border-radius: 12px;
            object-fit: cover;
            flex-shrink: 0;
            background: #f1f5f9;
        }
        .food-info {
            flex: 1;
            min-width: 0;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            min-height: 72px;
        }
        .food-name {
            font-weight: 700;
            font-size: 0.98rem;
            color: #1e293b;
            line-height: 1.3;
        }
        .food-sub {
            font-size: 0.78rem;
            color: #64748b;
            margin-top: 2px;
        }
        .food-price {
            color: #f59e0b;
            font-weight: 700;
            font-size: 0.95rem;
            margin-top: 6px;
        }
        .btn-plus-orange {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            border: none;
            background: #f59e0b;
            color: #ffffff;
            font-size: 1.2rem;
            font-weight: 700;
            line-height: 1;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            box-shadow: 0 2px 6px rgba(245, 158, 11, 0.35);
        }
        .btn-plus-orange:hover {
            background: #d97706;
        }
        .qty-stepper {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #fff7ed;
            border: 1px solid #fed7aa;
            border-radius: 20px;
            padding: 2px 6px;
        }
        .qty-btn {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            border: none;
            background: #f59e0b;
            color: #fff;
            font-weight: 700;
            line-height: 1;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .bottom-cart-bar {
            position: fixed;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 1030;
            background: #ffffff;
            border-top: 1px solid #e9ecef;
            padding: 10px 16px;
            box-shadow: 0 -4px 14px rgba(15, 23, 42, 0.06);
        }
        .bottom-cart-inner {
            max-width: 760px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .mini-thumbs {
            display: flex;
            align-items: center;
        }
        .mini-thumbs img {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #fff;
            box-shadow: 0 1px 4px rgba(0,0,0,0.15);
            margin-left: -10px;
        }
        .mini-thumbs img:first-child {
            margin-left: 0;
        }
        .btn-confirm-bar {
            flex: 1;
            background: #f59e0b;
            color: #ffffff;
            border: none;
            border-radius: 10px;
            padding: 11px 16px;
            font-weight: 700;
            font-size: 0.96rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 3px 10px rgba(245, 158, 11, 0.35);
        }
        .btn-confirm-bar:disabled {
            background: #cbd5e1;
            box-shadow: none;
        }
    </style>
</head>
<body>
<div class="order-shell">
    <div class="sticky-top-bar">
        <div class="d-flex align-items-center justify-content-between px-3 pt-3 pb-2">
            <a href="${pageContext.request.contextPath}/ban" class="circle-icon-btn" title="Quay lại danh sách bàn">
                ✕
            </a>

            <div class="text-center">
                <div class="fw-bold fs-6">🍜 Mì Cay Seoul 7 Cấp</div>
                <div class="small text-muted">
                    Đang gọi món cho:
                    <span class="fw-bold text-warning">
                        <c:out value="${banHienTai != null ? banHienTai.tenBan : 'Chưa chọn bàn'}"/>
                    </span>
                </div>
            </div>

            <a href="${pageContext.request.contextPath}/hoa-don" class="circle-icon-btn" title="Xem hóa đơn">
                🧾
            </a>
        </div>

        <div class="px-3 pb-2 d-flex align-items-center gap-2">
            <a href="${pageContext.request.contextPath}/ban" class="circle-icon-btn" style="border-radius: 10px; color: #f59e0b;">
                🏠
            </a>
            <div class="search-pill flex-grow-1">
                <span class="text-muted">🔍</span>
                <input type="text" id="searchFoodInput" placeholder="Bạn muốn tìm món gì ?" onkeyup="filterFoods()">
            </div>
        </div>

        <div class="cat-tabs" id="catTabs">
            <c:forEach var="entry" items="${menuTheoDanhMuc}" varStatus="st">
                <a href="#cat-${st.index}" class="cat-tab ${st.first ? 'active' : ''}" onclick="setActiveTab(this)">
                    <c:out value="${entry.key}"/>
                </a>
            </c:forEach>
        </div>
    </div>

    <div class="px-3 pt-1">
        <c:if test="${not empty errorMessage}">
            <div class="alert alert-danger mt-3 py-2 small">
                <c:out value="${errorMessage}"/>
            </div>
        </c:if>

        <c:forEach var="entry" items="${menuTheoDanhMuc}" varStatus="st">
            <div class="category-block" id="cat-${st.index}">
                <div class="section-heading"><c:out value="${entry.key}"/></div>

                <c:forEach var="sp" items="${entry.value}">
                    <c:set var="spImg" value="${empty sp.anhSanPham ? 'images/mon/default.jpg' : sp.anhSanPham}"/>
                    <c:set var="giaSo" value="${sp.giaTien != null ? sp.giaTien : 0}"/>
                    <div class="food-card" data-name="<c:out value='${sp.tenSanPham}'/>">
                        <img class="food-thumb"
                             src="${pageContext.request.contextPath}/${spImg}"
                             alt="<c:out value='${sp.tenSanPham}'/>"
                             onerror="this.onerror=null;this.src='data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22160%22 height=%22160%22><rect width=%22160%22 height=%22160%22 fill=%22%23fff7ed%22/><text x=%2250%25%22 y=%2252%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 fill=%22%23f59e0b%22 font-family=%22Arial%22 font-size=%2228%22>🍜</text></svg>';">

                        <div class="food-info">
                            <div>
                                <div class="food-name">
                                    <c:out value="${sp.tenSanPham}"/>
                                    <c:if test="${sp.capDoCay > 0}">
                                        <span class="badge bg-danger-subtle text-danger ms-1" style="font-size: 0.7rem;">
                                            🌶️ Cấp ${sp.capDoCay}
                                        </span>
                                    </c:if>
                                </div>
                                <c:if test="${not empty sp.moTa}">
                                    <div class="food-sub"><c:out value="${sp.moTa}"/></div>
                                </c:if>
                            </div>

                            <div class="d-flex align-items-center justify-content-between">
                                <div class="food-price">
                                    <fmt:formatNumber value="${giaSo}" pattern="#,##0"/>
                                </div>

                                <div id="ctrl-${sp.maSanPham}">
                                    <button type="button"
                                            class="btn-plus-orange"
                                            onclick="addItem(${sp.maSanPham}, '${sp.tenSanPham}', ${giaSo}, '${pageContext.request.contextPath}/${spImg}')">
                                        +
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </c:forEach>

        <c:if test="${empty menuTheoDanhMuc}">
            <div class="text-center text-muted py-5">
                Chưa có món nào đang bán trong thực đơn. Vui lòng thêm hoặc bật trạng thái <b>Đang bán</b> ở mục <b>Sản phẩm</b>.
            </div>
        </c:if>
    </div>
</div>

<div class="bottom-cart-bar">
    <div class="bottom-cart-inner">
        <div class="mini-thumbs" id="miniThumbs"></div>
        <button type="button" class="btn-confirm-bar" id="btnOpenCart" disabled data-bs-toggle="modal" data-bs-target="#cartModal">
            <span id="bottomTotalPrice">0</span>
            <span>Xem và xác nhận (<span id="bottomTotalQty">0</span>)</span>
        </button>
    </div>
</div>

<div class="modal fade" id="cartModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content rounded-4">
            <div class="modal-header">
                <h5 class="modal-title fw-bold fs-6">
                    Xác nhận gọi món - <span class="text-warning"><c:out value="${banHienTai != null ? banHienTai.tenBan : ''}"/></span>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form method="post" action="${pageContext.request.contextPath}/goi-mon">
                <input type="hidden" name="maBan" value="${banHienTai != null ? banHienTai.maBan : ''}">
                <div class="modal-body" id="cartModalBody"></div>
                <div class="modal-footer justify-content-between">
                    <div>
                        <div class="small text-muted">Tổng thanh toán tạm tính</div>
                        <div class="fw-bold fs-5 text-warning" id="modalTotalPrice">0 đ</div>
                    </div>
                    <button type="submit" class="btn fw-bold text-white px-4" style="background:#f59e0b;">
                        ✓ Xác nhận gọi món
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const cart = {};
    const fallbackSvg = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='80' height='80'><rect width='80' height='80' fill='%23fff7ed'/><text x='50%' y='54%' dominant-baseline='middle' text-anchor='middle' font-size='24'>🍜</text></svg>";

    function formatMoney(num) {
        return Math.round(num).toLocaleString('vi-VN');
    }

    function addItem(id, name, price, img) {
        if (!cart[id]) {
            cart[id] = { id: id, name: name, price: Number(price), img: img, qty: 0 };
        }
        cart[id].qty += 1;
        renderItemControl(id);
        renderBottomBar();
    }

    function changeQty(id, delta) {
        if (!cart[id]) return;
        cart[id].qty += delta;
        if (cart[id].qty <= 0) {
            delete cart[id];
        }
        renderItemControl(id);
        renderBottomBar();
        renderModalBody();
    }

    function renderItemControl(id) {
        const box = document.getElementById('ctrl-' + id);
        if (!box) return;
        const item = cart[id];
        if (!item || item.qty <= 0) {
            const card = box.closest('.food-card');
            const name = card ? card.getAttribute('data-name').replace(/'/g, "\\'") : '';
            const priceText = card ? card.querySelector('.food-price').innerText.replace(/\./g, '').replace(/,/g, '').trim() : '0';
            const imgSrc = card ? card.querySelector('.food-thumb').getAttribute('src') : '';
            box.innerHTML = `<button type="button" class="btn-plus-orange" onclick="addItem(${id}, '${name}', ${priceText}, '${imgSrc}')">+</button>`;
        } else {
            box.innerHTML = `
                <div class="qty-stepper">
                    <button type="button" class="qty-btn" onclick="changeQty(${id}, -1)">−</button>
                    <span class="fw-bold small px-1">${item.qty}</span>
                    <button type="button" class="qty-btn" onclick="changeQty(${id}, 1)">+</button>
                </div>
            `;
        }
    }

    function renderBottomBar() {
        const items = Object.values(cart);
        let totalQty = 0;
        let totalPrice = 0;
        items.forEach(it => {
            totalQty += it.qty;
            totalPrice += it.qty * it.price;
        });

        document.getElementById('bottomTotalPrice').innerText = formatMoney(totalPrice);
        document.getElementById('bottomTotalQty').innerText = totalQty;
        document.getElementById('btnOpenCart').disabled = totalQty === 0;

        const thumbsBox = document.getElementById('miniThumbs');
        thumbsBox.innerHTML = items.slice(0, 3).map(it =>
            `<img src="${it.img}" onerror="this.onerror=null;this.src='${fallbackSvg}';" alt="">`
        ).join('');

        renderModalBody();
    }

    function renderModalBody() {
        const body = document.getElementById('cartModalBody');
        const items = Object.values(cart);
        if (items.length === 0) {
            body.innerHTML = '<div class="text-center text-muted py-4">Chưa có món nào được chọn.</div>';
            document.getElementById('modalTotalPrice').innerText = '0 đ';
            return;
        }

        let totalPrice = 0;
        body.innerHTML = items.map(it => {
            const sub = it.qty * it.price;
            totalPrice += sub;
            return `
                <div class="d-flex align-items-center justify-content-between py-2 border-bottom">
                    <input type="hidden" name="maSanPham" value="${it.id}">
                    <input type="hidden" name="soLuong" value="${it.qty}">
                    <input type="hidden" name="donGia" value="${it.price}">
                    <div class="pe-2">
                        <div class="fw-semibold">${it.name}</div>
                        <div class="small text-warning fw-semibold">${formatMoney(it.price)} đ</div>
                    </div>
                    <div class="qty-stepper">
                        <button type="button" class="qty-btn" onclick="changeQty(${it.id}, -1)">−</button>
                        <span class="fw-bold small px-1">${it.qty}</span>
                        <button type="button" class="qty-btn" onclick="changeQty(${it.id}, 1)">+</button>
                    </div>
                </div>
            `;
        }).join('');

        document.getElementById('modalTotalPrice').innerText = formatMoney(totalPrice) + ' đ';
    }

    function filterFoods() {
        const kw = document.getElementById('searchFoodInput').value.trim().toLowerCase();
        document.querySelectorAll('.category-block').forEach(block => {
            let visibleCount = 0;
            block.querySelectorAll('.food-card').forEach(card => {
                const name = (card.getAttribute('data-name') || '').toLowerCase();
                const match = name.includes(kw);
                card.style.display = match ? 'flex' : 'none';
                if (match) visibleCount++;
            });
            block.style.display = visibleCount > 0 ? 'block' : 'none';
        });
    }

    function setActiveTab(el) {
        document.querySelectorAll('.cat-tab').forEach(t => t.classList.remove('active'));
        el.classList.add('active');
    }
</script>
</body>
</html>