-- ============================================================
-- 0. TẠO LẠI DATABASE QUAN LY QUAN MI CAY
-- ============================================================
USE master;
GO

IF EXISTS (
    SELECT 1
    FROM sys.databases
    WHERE name = N'QuanLyQuanMiCay'
)
BEGIN
    ALTER DATABASE QuanLyQuanMiCay
    SET SINGLE_USER WITH ROLLBACK IMMEDIATE;

    DROP DATABASE QuanLyQuanMiCay;
END;
GO

CREATE DATABASE QuanLyQuanMiCay;
GO

USE QuanLyQuanMiCay;
GO

-- ============================================================
-- 1. NHÓM BẢNG NGƯỜI DÙNG, NHÂN SỰ & BÀN
-- ============================================================
CREATE TABLE dbo.KHACH_HANG (
    ma_khach_hang INT IDENTITY(1,1) PRIMARY KEY,
    ho_ten        NVARCHAR(255) NOT NULL
);
GO

CREATE TABLE dbo.QUAN_LY (
    ma_quan_ly    INT IDENTITY(1,1) PRIMARY KEY,
    ngay_nhan_chuc DATE NULL,
    ma_nguoi_dung  INT NULL
);
GO

CREATE TABLE dbo.NHAN_VIEN (
    ma_nhan_vien  INT IDENTITY(1,1) PRIMARY KEY,
    ten_nhan_vien NVARCHAR(255) NULL,
    so_dien_thoai VARCHAR(20) NULL,
    chuc_vu       NVARCHAR(100) NULL,
    tien_luong_gio DECIMAL(12,2) NULL,
    tinh_gio_lam  FLOAT NOT NULL CONSTRAINT DF_NV_GIO_LAM DEFAULT 0,
    trang_thai    NVARCHAR(50) NULL,
    ma_nguoi_dung INT NULL,
    ma_quan_ly    INT NULL,
    CONSTRAINT FK_NV_QuanLy FOREIGN KEY (ma_quan_ly) REFERENCES dbo.QUAN_LY(ma_quan_ly)
);
GO

CREATE TABLE dbo.BAN (
    ma_ban     INT IDENTITY(1,1) PRIMARY KEY,
    ten_ban    NVARCHAR(100) NOT NULL,
    khu_vuc    NVARCHAR(50)  NOT NULL CONSTRAINT DF_BAN_KHU_VUC DEFAULT N'Tầng 1',
    so_ghe     INT           NOT NULL CONSTRAINT DF_BAN_SO_GHE DEFAULT 4,
    trang_thai NVARCHAR(50)  NOT NULL CONSTRAINT DF_BAN_TRANG_THAI DEFAULT N'Trống',
    hinh_anh   NVARCHAR(255) NULL
);
GO

-- ============================================================
-- 2. NHÓM BẢNG THỰC ĐƠN, KHUYẾN MÃI & VOUCHER
-- ============================================================
CREATE TABLE dbo.SAN_PHAM (
    ma_san_pham   INT IDENTITY(1,1) PRIMARY KEY,
    ten_san_pham  NVARCHAR(255) NOT NULL,
    gia_tien      DECIMAL(12,2) NOT NULL,
    anh_san_pham  NVARCHAR(500) NULL,
    mo_ta         NVARCHAR(MAX) NULL,
    loai_san_pham NVARCHAR(100) NOT NULL CONSTRAINT DF_SP_LOAI DEFAULT N'Mì cay',
    cap_do_cay    INT           NOT NULL CONSTRAINT DF_SP_CAY DEFAULT 0,
    don_vi_tinh   NVARCHAR(50)  NULL CONSTRAINT DF_SP_DVT DEFAULT N'Phần',
    trang_thai    NVARCHAR(50)  NOT NULL CONSTRAINT DF_SP_TRANG_THAI DEFAULT N'Đang bán',
    ngay_tao      DATETIME      NOT NULL CONSTRAINT DF_SP_NGAY_TAO DEFAULT GETDATE(),
    ngay_cap_nhat DATETIME      NOT NULL CONSTRAINT DF_SP_NGAY_CAP_NHAT DEFAULT GETDATE(),
    CONSTRAINT CK_SP_Gia CHECK (gia_tien > 0),
    CONSTRAINT CK_SP_CapDoCay CHECK (cap_do_cay BETWEEN 0 AND 7),
    CONSTRAINT CK_SP_TrangThai CHECK (trang_thai IN (N'Đang bán', N'Ngừng bán'))
);
GO

CREATE TABLE dbo.KHUYEN_MAI (
    ma_khuyen_mai INT IDENTITY(1,1) PRIMARY KEY,
    ma_code       VARCHAR(50) UNIQUE NULL,
    ten_khuyen_mai NVARCHAR(255) NULL,
    loai_giam     NVARCHAR(50) NULL,
    giam_toi_da   DECIMAL(12,2) NULL,
    gia_tri_giam  DECIMAL(12,2) NULL,
    ngay_bat_dau  DATETIME NULL,
    ngay_ket_thuc DATETIME NULL,
    trang_thai    BIT NULL CONSTRAINT DF_KM_TRANG_THAI DEFAULT 1
);
GO

CREATE TABLE dbo.VOUCHER (
    ma_voucher            VARCHAR(255) PRIMARY KEY,
    ma_code               VARCHAR(50) UNIQUE NULL,
    ten_voucher           NVARCHAR(255) NULL,
    loai_giam             NVARCHAR(50) NULL,
    gia_tri_giam          DECIMAL(12,2) NULL,
    gia_tri_don_toi_thieu DECIMAL(12,2) NULL,
    so_luong              INT NULL,
    so_luong_da_dung      INT NULL CONSTRAINT DF_VC_DA_DUNG DEFAULT 0,
    trang_thai            BIT NULL CONSTRAINT DF_VC_TRANG_THAI DEFAULT 1,
    ngay_ket_thuc         DATETIME NULL
);
GO

-- ============================================================
-- 3. NHÓM BẢNG HÓA ĐƠN & NHẬT KÝ HOẠT ĐỘNG
-- ============================================================
CREATE TABLE dbo.HOA_DON (
    ma_hoa_don             INT IDENTITY(1,1) PRIMARY KEY,
    ngay_lap               DATETIME NULL CONSTRAINT DF_HD_NGAY_LAP DEFAULT GETDATE(),
    tong_tien              DECIMAL(12,2) NULL,
    trang_thai             NVARCHAR(50) NULL,
    phuong_thuc_thanh_toan NVARCHAR(50) NULL,
    ma_don_hang            INT NULL,
    ma_nhan_vien           INT NULL,
    ma_khach_hang          INT NULL,
    ma_khuyen_mai          INT NULL,
    ma_voucher             VARCHAR(255) NULL,
    CONSTRAINT FK_HD_NhanVien FOREIGN KEY (ma_nhan_vien) REFERENCES dbo.NHAN_VIEN(ma_nhan_vien),
    CONSTRAINT FK_HD_KhachHang FOREIGN KEY (ma_khach_hang) REFERENCES dbo.KHACH_HANG(ma_khach_hang),
    CONSTRAINT FK_HD_KhuyenMai FOREIGN KEY (ma_khuyen_mai) REFERENCES dbo.KHUYEN_MAI(ma_khuyen_mai),
    CONSTRAINT FK_HD_Voucher FOREIGN KEY (ma_voucher) REFERENCES dbo.VOUCHER(ma_voucher)
);
GO

CREATE TABLE dbo.HOA_DON_CHI_TIET (
    ma_ct_hoa_don INT IDENTITY(1,1) PRIMARY KEY,
    so_luong       INT NOT NULL,
    don_gia        DECIMAL(12,2) NOT NULL,
    thanh_tien     DECIMAL(12,2) NOT NULL,
    ma_hoa_don     INT NULL,
    ma_san_pham    INT NULL,
    CONSTRAINT FK_CTHD_HoaDon FOREIGN KEY (ma_hoa_don) REFERENCES dbo.HOA_DON(ma_hoa_don),
    CONSTRAINT FK_CTHD_SanPham FOREIGN KEY (ma_san_pham) REFERENCES dbo.SAN_PHAM(ma_san_pham)
);
GO

CREATE TABLE dbo.NHAT_KI_HOAT_DONG (
    ma_nhat_ki   INT IDENTITY(1,1) PRIMARY KEY,
    hanh_dong    NVARCHAR(255) NULL,
    thoi_gian    DATETIME NULL CONSTRAINT DF_NK_THOI_GIAN DEFAULT GETDATE(),
    ma_nhan_vien INT NULL,
    CONSTRAINT FK_NK_NhanVien FOREIGN KEY (ma_nhan_vien) REFERENCES dbo.NHAN_VIEN(ma_nhan_vien)
);
GO

-- ============================================================
-- 4. DỮ LIỆU MẪU: BÀN
-- ============================================================
INSERT INTO dbo.BAN (ten_ban, khu_vuc, so_ghe, trang_thai, hinh_anh)
VALUES
    (N'Bàn 01', N'Tầng 1', 4, N'Trống',    N'images/ban/ban-01.jpg'),
    (N'Bàn 02', N'Tầng 1', 4, N'Có khách', N'images/ban/ban-02.jpg'),
    (N'Bàn 03', N'Tầng 2', 4, N'Có khách', N'images/ban/ban-03.jpg'),
    (N'Bàn 04', N'Tầng 2', 6, N'Trống',    N'images/ban/ban-04.jpg'),
    (N'Bàn 05', N'Tầng 3', 4, N'Trống',    N'images/ban/ban-05.jpg'),
    (N'Bàn 06', N'Tầng 3', 6, N'Trống',    N'images/ban/ban-06.jpg'),
    (N'Bàn 07', N'Tầng 3', 8, N'Trống',    N'images/ban/ban-07.jpg');
GO

-- ============================================================
-- 5. DỮ LIỆU MẪU: SẢN PHẨM
-- ============================================================
INSERT INTO dbo.SAN_PHAM (ten_san_pham, gia_tien, anh_san_pham, mo_ta, loai_san_pham, cap_do_cay, don_vi_tinh, trang_thai)
VALUES
    (N'Mì cay bò',       45000, N'/image/mi-cay-bo.png',    N'Mì cay bò thơm ngon',         N'Mì cay', 2, N'Phần', N'Đang bán'),
    (N'Mì cay hải sản',  50000, N'/image/mi-hai-san.png',  N'Mì cay hải sản tươi ngon',    N'Mì cay', 3, N'Phần', N'Đang bán'),
    (N'Mì cay xúc xích', 40000, N'/image/mi-xuc-xich.png', N'Mì cay xúc xích',             N'Mì cay', 1, N'Phần', N'Đang bán'),
    (N'Mì cay thập cẩm', 55000, N'/image/mi-thap-cam.png', N'Mì cay thập cẩm đặc biệt',    N'Mì cay', 3, N'Phần', N'Đang bán'),
    (N'Mì cay kim chi',  45000, N'/image/mi-kim-chi.png',  N'Mì cay kim chi Hàn Quốc',     N'Mì cay', 2, N'Phần', N'Đang bán');
GO

-- ============================================================
-- 6. DỮ LIỆU MẪU: KHUYẾN MÃI, voucher
-- ============================================================
INSERT INTO dbo.KHUYEN_MAI (
    ma_code, ten_khuyen_mai, loai_giam, giam_toi_da, gia_tri_giam,
    ngay_bat_dau, ngay_ket_thuc, trang_thai
)
VALUES
    ('KM_MICAY15',   N'Giảm 15% cho hóa đơn mì cay cấp độ',              N'Phần trăm', 50000.00, 15.00,    '2026-11-01 00:00:00', '2026-12-31 23:59:59', 1),
    ('KM_GIAM20K',   N'Giảm ngay 20.000đ cho combo đồ uống & mì cay',   N'Tiền mặt',  20000.00, 20000.00, '2026-11-01 00:00:00', '2026-12-31 23:59:59', 1),
    ('KM_TRUA25',    N'Ưu đãi khung giờ trưa giảm 25%',                  N'Phần trăm', 40000.00, 25.00,    '2026-11-01 00:00:00', '2026-12-15 23:59:59', 1),
    ('KM_THANG10',   N'Chương trình khuyến mãi tháng 10 đã kết thúc',   N'Phần trăm', 30000.00, 10.00,    '2026-10-01 00:00:00', '2026-10-31 23:59:59', 0),
    ('KM_KHAITRUONG',N'Khuyến mãi khai trương đợt đầu đã hết hạn',       N'Tiền mặt',  25000.00, 25000.00, '2026-09-01 00:00:00', '2026-09-30 23:59:59', 0);
GO
 -- ============================================================
--  DỮ LIỆU MẪU:voucher
-- ============================================================
INSERT INTO dbo.VOUCHER (
    ma_voucher,
    ma_code,
    ten_voucher,
    loai_giam,
    gia_tri_giam,
    gia_tri_don_toi_thieu,
    so_luong,
    so_luong_da_dung,
    trang_thai,
    ngay_ket_thuc
)
VALUES
    ('VC01', 'VC_MICAY10K',  N'Giảm 10.000đ cho tô mì cay bất kỳ',       N'Tiền mặt', 10000.00,  40000.00, 100, 12, 1, '2026-12-31 23:59:59'),
    ('VC02', 'VC_GIAM15PCT', N'Giảm 15% cho hóa đơn từ 100.000đ',         N'Phần trăm',   15.00, 100000.00,  50,  8, 1, '2026-12-31 23:59:59'),
    ('VC03', 'VC_COMBO20K',  N'Giảm 20.000đ cho đơn từ 120.000đ',         N'Tiền mặt', 20000.00, 120000.00,  80, 25, 1, '2026-12-25 23:59:59'),
    ('VC04', 'VC_VIP25PCT',  N'Giảm 25% cho hóa đơn nhóm từ 180.000đ',    N'Phần trăm',   25.00, 180000.00,  30,  5, 1, '2026-12-31 23:59:59'),
    ('VC05', 'VC_HETHAN',    N'Voucher khai trương đã hết lượt sử dụng',    N'Tiền mặt', 15000.00,  50000.00,  50, 50, 0, '2026-10-31 23:59:59');
GO

-- ============================================================
-- 7. KIỂM TRA DỮ LIỆU
-- ============================================================
SELECT * FROM dbo.BAN ORDER BY ma_ban;
SELECT * FROM dbo.SAN_PHAM ORDER BY ma_san_pham;
SELECT * FROM dbo.KHUYEN_MAI ORDER BY ma_khuyen_mai;
SELECT * FROM dbo.VOUCHER ORDER BY ma_voucher;
GO
select * from dbo.SAN_PHAM