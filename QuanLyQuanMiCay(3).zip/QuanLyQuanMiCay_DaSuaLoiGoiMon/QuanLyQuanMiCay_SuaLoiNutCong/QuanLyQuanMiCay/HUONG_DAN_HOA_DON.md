# Hướng dẫn cài đặt chức năng hóa đơn

## 1. Cập nhật cơ sở dữ liệu

- Nếu tạo database mới bằng `quan-ly-my-cay.sql`, các cột `HOA_DON.ma_ban` và `HOA_DON_CHI_TIET.trang_thai_mon` đã có sẵn.
- Nếu đang dùng database cũ, mở SQL Server Management Studio và chạy file `cap-nhat-hoa-don.sql` một lần.

## 2. QR chuyển khoản thật

Thiết lập 3 biến môi trường cho cấu hình chạy Tomcat trong IntelliJ IDEA:

- `VIETQR_BANK_BIN`: mã BIN ngân hàng nhận tiền (theo danh sách VietQR).
- `VIETQR_ACCOUNT_NO`: số tài khoản của quán.
- `VIETQR_ACCOUNT_NAME`: tên chủ tài khoản.

Khởi động lại Tomcat sau khi thêm biến. Khi chưa cấu hình đủ 3 biến, trang thanh toán sẽ thông báo chưa có QR ngân hàng; hệ thống không tự bịa số tài khoản.

## 3. Luồng sử dụng

1. Vào Bàn, chọn bàn và gọi món như hiện tại.
2. Nếu bàn đã có hóa đơn chưa thanh toán, món gọi thêm được nối vào hóa đơn đó.
3. Trong hóa đơn tại bàn, chọn bộ lọc Tất cả món / Đơn hàng đã ra / Đơn hàng chưa ra. Nhấn `Xác nhận món đã ra` khi bếp đã giao món.
4. Nhấn `Trả khách` để mở bill thanh toán. Món chưa ra được hiển thị 0đ và chữ nhạt.
5. Sau khi nhận tiền, nhấn `Đã nhận thanh toán`. Bàn được chuyển về `Trống`.
6. Hóa đơn đã thanh toán nằm trong danh sách tương ứng; mở hóa đơn để in.

## 4. Lưu ý

Chức năng in dùng hộp thoại in của trình duyệt. Việc xác nhận đã nhận tiền hiện do nhân viên thao tác; QR VietQR tạo yêu cầu chuyển khoản nhưng ứng dụng chưa tích hợp webhook/ngân hàng để tự xác nhận tiền vào tài khoản.

## 5. Cập nhật điều hướng và gọi món

- Trang Hóa đơn đã được bổ sung lại thanh menu bên trái với nhóm `Tổng quan & Bán hàng` và các mục quản lý khác.
- Từ Trang chủ, nút `Gọi món / Mở bàn` dẫn đến `/goi-mon?maBan=...`; với bàn đang có khách có hai nút riêng `Gọi thêm món` và `Trả khách`.
- Trong Quản lý bàn, `Trả khách` mở hóa đơn đang chờ thanh toán thay vì tự ý chuyển bàn về Trống.
- Sau khi xác nhận gọi món, hệ thống chuyển thẳng đến hóa đơn của bàn. Tại hóa đơn chưa thanh toán có nút `Gọi thêm món`.
- Đường dẫn `/hoa-don?maBan=...` tự mở hóa đơn chưa thanh toán của bàn; nếu bàn chưa có hóa đơn thì chuyển sang trang gọi món.
