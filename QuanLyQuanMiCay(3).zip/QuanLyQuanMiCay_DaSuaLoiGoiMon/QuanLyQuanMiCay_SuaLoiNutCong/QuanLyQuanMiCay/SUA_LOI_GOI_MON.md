# Sửa lỗi nút + trong trang gọi món

- Trang `src/main/webapp/jsp/goi_mon.jsp` đã được sửa để dùng JavaScript event delegation thay cho `onclick` nhúng dữ liệu trực tiếp.
- Nhấn `+` sẽ tăng số lượng, cập nhật tổng số món và tổng tiền ở thanh dưới.
- Nhấn `-` sẽ giảm số lượng; về 0 sẽ khôi phục nút `+`.
- Nút `Xem và xác nhận` chỉ được bật khi đã chọn ít nhất một món.
- Trong giỏ xác nhận, mỗi món gửi `maSanPham`, `soLuong`, `donGia` đến `GoiMonServlet`.

## Cách cập nhật
1. Sao lưu project hiện tại.
2. Thay file `src/main/webapp/jsp/goi_mon.jsp` bằng file cùng tên trong gói này (hoặc chép đè toàn bộ project).
3. IntelliJ: Maven > Reload All Projects.
4. Build > Rebuild Project.
5. Dừng Tomcat, xóa deployment cũ trong cấu hình Tomcat nếu vẫn dùng bản cũ, sau đó chạy lại.
6. Vào Bán hàng > chọn bàn > nhấn dấu `+`. Số lượng ở thanh dưới phải tăng từ 0 lên 1 và nút xác nhận sáng lên.
7. Nhấn `Xem và xác nhận` > kiểm tra món và số lượng > `Xác nhận gọi món`.

Lưu ý: dấu `+` chỉ thêm vào giỏ tạm trên trình duyệt. Đơn chỉ được ghi vào database sau khi nhấn `Xác nhận gọi món`.
