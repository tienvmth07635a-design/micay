USE QuanLyQuanMiCay;
GO

-- Bổ sung mã bàn cho hóa đơn nếu database cũ chưa có.
IF COL_LENGTH('dbo.HOA_DON', 'ma_ban') IS NULL
BEGIN
    ALTER TABLE dbo.HOA_DON ADD ma_ban INT NULL;
END;
GO

-- Tạo khóa ngoại hóa đơn - bàn.
IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_HD_Ban'
)
BEGIN
    ALTER TABLE dbo.HOA_DON
    ADD CONSTRAINT FK_HD_Ban
    FOREIGN KEY (ma_ban) REFERENCES dbo.BAN(ma_ban);
END;
GO

-- Đồng bộ tên cột trạng thái món mà GoiMonServlet.java đang sử dụng.
-- SQL cũ của một số phiên bản dùng da_ra_mon (BIT);
-- source hiện tại dùng trang_thai_mon (NVARCHAR).
IF COL_LENGTH('dbo.HOA_DON_CHI_TIET', 'trang_thai_mon') IS NULL
BEGIN
    ALTER TABLE dbo.HOA_DON_CHI_TIET
    ADD trang_thai_mon NVARCHAR(30) NULL;

    IF COL_LENGTH('dbo.HOA_DON_CHI_TIET', 'da_ra_mon') IS NOT NULL
    BEGIN
        UPDATE dbo.HOA_DON_CHI_TIET
        SET trang_thai_mon =
            CASE WHEN da_ra_mon = 1 THEN N'Đã ra' ELSE N'Chưa ra' END;
    END
    ELSE
    BEGIN
        UPDATE dbo.HOA_DON_CHI_TIET
        SET trang_thai_mon = N'Chưa ra';
    END;

    ALTER TABLE dbo.HOA_DON_CHI_TIET
    ALTER COLUMN trang_thai_mon NVARCHAR(30) NOT NULL;

    ALTER TABLE dbo.HOA_DON_CHI_TIET
    ADD CONSTRAINT DF_CTHD_TRANG_THAI
    DEFAULT N'Chưa ra' FOR trang_thai_mon;
END;
GO

-- Kiểm tra kết quả sau cập nhật.
SELECT TOP 20
    ma_ct_hoa_don, ma_hoa_don, ma_san_pham,
    so_luong, don_gia, thanh_tien, trang_thai_mon
FROM dbo.HOA_DON_CHI_TIET
ORDER BY ma_ct_hoa_don DESC;
GO
