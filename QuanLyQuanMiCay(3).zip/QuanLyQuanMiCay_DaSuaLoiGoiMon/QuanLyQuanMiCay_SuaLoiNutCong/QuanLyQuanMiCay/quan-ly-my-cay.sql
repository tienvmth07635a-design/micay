/* ================================================================
   DATABASE: QuanLyQuanMiCay
   SQL Server 2019+ / SSMS

   LUU Y:
   - Script nay XOA database QuanLyQuanMiCay cu va tao lai tu dau.
   - Hay sao luu database cu truoc khi chay neu can giu du lieu.
   - Ten bang/cot duoc doi chieu voi cac Entity Java trong project:
     Ban, SanPham, KhachHang, QuanLy, NhanVien, KhuyenMai, Voucher,
     HoaDon, HoaDonChiTiet, NhatKiHoatDong.
   - Chi tiet mon dung cot trang_thai_mon (Chua ra / Da ra),
     dung voi HoaDonChiTiet.java; khong dung da_ra_mon BIT.
   ================================================================ */

USE master;
GO

IF DB_ID(N'QuanLyQuanMiCay') IS NOT NULL
BEGIN
    ALTER DATABASE QuanLyQuanMiCay SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE QuanLyQuanMiCay;
END;
GO

CREATE DATABASE QuanLyQuanMiCay;
GO

USE QuanLyQuanMiCay;
GO

/* ================================================================
   1. KHACH HANG
   ================================================================ */
CREATE TABLE dbo.KHACH_HANG (
                                ma_khach_hang INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                                ten_khach_hang NVARCHAR(255) NULL,
                                so_dien_thoai VARCHAR(20) NULL,
                                diem_tich_luy INT NOT NULL CONSTRAINT DF_KH_DIEM DEFAULT (0),
                                CONSTRAINT CK_KH_DIEM CHECK (diem_tich_luy >= 0)
);
GO

/* ================================================================
   2. QUAN LY
   ================================================================ */
CREATE TABLE dbo.QUAN_LY (
                             ma_quan_ly INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                             ten_quan_ly NVARCHAR(255) NULL,
                             so_dien_thoai VARCHAR(20) NULL,
                             trang_thai NVARCHAR(50) NULL CONSTRAINT DF_QL_TRANG_THAI DEFAULT N'Đang làm',
                             ngay_nhan_chuc DATE NULL,
                             ma_nguoi_dung INT NULL
);
GO

/* ================================================================
   3. NHAN VIEN
   ================================================================ */
CREATE TABLE dbo.NHAN_VIEN (
                               ma_nhan_vien INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                               ten_nhan_vien NVARCHAR(255) NULL,
                               so_dien_thoai VARCHAR(20) NULL,
                               chuc_vu NVARCHAR(100) NULL,
                               tien_luong_gio DECIMAL(12,2) NULL,
                               tinh_gio_lam FLOAT NOT NULL CONSTRAINT DF_NV_GIO_LAM DEFAULT (0),
                               trang_thai NVARCHAR(50) NULL CONSTRAINT DF_NV_TRANG_THAI DEFAULT N'Đang làm',
                               ma_nguoi_dung INT NULL,
                               ma_quan_ly INT NULL,
                               CONSTRAINT FK_NV_QUAN_LY FOREIGN KEY (ma_quan_ly)
                                   REFERENCES dbo.QUAN_LY(ma_quan_ly),
                               CONSTRAINT CK_NV_LUONG CHECK (tien_luong_gio IS NULL OR tien_luong_gio >= 0),
                               CONSTRAINT CK_NV_GIO_LAM CHECK (tinh_gio_lam >= 0)
);
GO

/* ================================================================
   4. BAN
   ================================================================ */
CREATE TABLE dbo.BAN (
                         ma_ban INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                         ten_ban NVARCHAR(100) NOT NULL,
                         khu_vuc NVARCHAR(50) NOT NULL CONSTRAINT DF_BAN_KHU_VUC DEFAULT N'Tầng 1',
                         so_ghe INT NOT NULL CONSTRAINT DF_BAN_SO_GHE DEFAULT (4),
                         trang_thai NVARCHAR(50) NOT NULL CONSTRAINT DF_BAN_TRANG_THAI DEFAULT N'Trống',
                         hinh_anh NVARCHAR(255) NULL,
                         CONSTRAINT CK_BAN_SO_GHE CHECK (so_ghe > 0),
                         CONSTRAINT CK_BAN_TRANG_THAI CHECK (trang_thai IN (N'Trống', N'Có khách', N'Đã đặt'))
);
GO

/* ================================================================
   5. SAN PHAM / THUC DON
   ================================================================ */
CREATE TABLE dbo.SAN_PHAM (
                              ma_san_pham INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                              ten_san_pham NVARCHAR(255) NOT NULL,
                              gia_tien DECIMAL(12,2) NOT NULL,
                              anh_san_pham NVARCHAR(500) NULL,
                              mo_ta NVARCHAR(MAX) NULL,
                              loai_san_pham NVARCHAR(100) NOT NULL CONSTRAINT DF_SP_LOAI DEFAULT N'Mì cay',
                              cap_do_cay INT NOT NULL CONSTRAINT DF_SP_CAY DEFAULT (0),
                              don_vi_tinh NVARCHAR(50) NULL CONSTRAINT DF_SP_DVT DEFAULT N'Phần',
                              trang_thai NVARCHAR(50) NOT NULL CONSTRAINT DF_SP_TRANG_THAI DEFAULT N'Đang bán',
                              ngay_tao DATETIME2(0) NOT NULL CONSTRAINT DF_SP_NGAY_TAO DEFAULT SYSDATETIME(),
                              ngay_cap_nhat DATETIME2(0) NOT NULL CONSTRAINT DF_SP_NGAY_CAP_NHAT DEFAULT SYSDATETIME(),
                              CONSTRAINT CK_SP_GIA CHECK (gia_tien > 0),
                              CONSTRAINT CK_SP_CAP_DO_CAY CHECK (cap_do_cay BETWEEN 0 AND 7),
                              CONSTRAINT CK_SP_TRANG_THAI CHECK (trang_thai IN (N'Đang bán', N'Ngừng bán'))
);
GO

/* ================================================================
   6. KHUYEN MAI
   ================================================================ */
CREATE TABLE dbo.KHUYEN_MAI (
                                ma_khuyen_mai INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                                ma_code VARCHAR(50) NULL UNIQUE,
                                ten_khuyen_mai NVARCHAR(255) NULL,
                                loai_giam NVARCHAR(50) NULL,
                                giam_toi_da DECIMAL(12,2) NULL,
                                gia_tri_giam DECIMAL(12,2) NULL,
                                ngay_bat_dau DATETIME2(0) NULL,
                                ngay_ket_thuc DATETIME2(0) NULL,
                                trang_thai BIT NOT NULL CONSTRAINT DF_KM_TRANG_THAI DEFAULT (1),
                                CONSTRAINT CK_KM_GIA_TRI CHECK (gia_tri_giam IS NULL OR gia_tri_giam >= 0),
                                CONSTRAINT CK_KM_THOI_GIAN CHECK (ngay_bat_dau IS NULL OR ngay_ket_thuc IS NULL OR ngay_ket_thuc >= ngay_bat_dau)
);
GO

/* ================================================================
   7. VOUCHER
   ================================================================ */
CREATE TABLE dbo.VOUCHER (
                             ma_voucher VARCHAR(255) NOT NULL PRIMARY KEY,
                             ma_code VARCHAR(50) NULL UNIQUE,
                             ten_voucher NVARCHAR(255) NULL,
                             loai_giam NVARCHAR(50) NULL,
                             gia_tri_giam DECIMAL(12,2) NULL,
                             gia_tri_don_toi_thieu DECIMAL(12,2) NULL,
                             so_luong INT NULL,
                             so_luong_da_dung INT NOT NULL CONSTRAINT DF_VC_DA_DUNG DEFAULT (0),
                             trang_thai BIT NOT NULL CONSTRAINT DF_VC_TRANG_THAI DEFAULT (1),
                             ngay_ket_thuc DATE NULL,
                             CONSTRAINT CK_VC_SO_LUONG CHECK (so_luong IS NULL OR so_luong >= 0),
                             CONSTRAINT CK_VC_DA_DUNG CHECK (so_luong_da_dung >= 0),
                             CONSTRAINT CK_VC_GIA_TRI CHECK (gia_tri_giam IS NULL OR gia_tri_giam >= 0)
);
GO

/* ================================================================
   8. HOA DON
   - Moi ban chi co toi da mot hoa don Chua thanh toan.
   - ma_ban co the NULL cho hoa don mang ve neu project su dung.
   ================================================================ */
CREATE TABLE dbo.HOA_DON (
                             ma_hoa_don INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                             ma_ban INT NULL,
                             ngay_lap DATETIME2(0) NOT NULL CONSTRAINT DF_HD_NGAY_LAP DEFAULT SYSDATETIME(),
                             ngay_tao DATETIME2(0) NOT NULL CONSTRAINT DF_HD_NGAY_TAO DEFAULT SYSDATETIME(),
                             ngay_thanh_toan DATETIME2(0) NULL,
                             tong_tien DECIMAL(12,2) NOT NULL CONSTRAINT DF_HD_TONG_TIEN DEFAULT (0),
                             trang_thai NVARCHAR(50) NOT NULL CONSTRAINT DF_HD_TRANG_THAI DEFAULT N'Chưa thanh toán',
                             phuong_thuc_thanh_toan NVARCHAR(50) NULL,
                             ma_nhan_vien INT NULL,
                             ma_khach_hang INT NULL,
                             ma_khuyen_mai INT NULL,
                             ma_voucher VARCHAR(255) NULL,
                             ma_giao_dich NVARCHAR(100) NULL,
                             ghi_chu NVARCHAR(500) NULL,
                             CONSTRAINT FK_HD_BAN FOREIGN KEY (ma_ban) REFERENCES dbo.BAN(ma_ban),
                             CONSTRAINT FK_HD_NHAN_VIEN FOREIGN KEY (ma_nhan_vien) REFERENCES dbo.NHAN_VIEN(ma_nhan_vien),
                             CONSTRAINT FK_HD_KHACH_HANG FOREIGN KEY (ma_khach_hang) REFERENCES dbo.KHACH_HANG(ma_khach_hang),
                             CONSTRAINT FK_HD_KHUYEN_MAI FOREIGN KEY (ma_khuyen_mai) REFERENCES dbo.KHUYEN_MAI(ma_khuyen_mai),
                             CONSTRAINT FK_HD_VOUCHER FOREIGN KEY (ma_voucher) REFERENCES dbo.VOUCHER(ma_voucher),
                             CONSTRAINT CK_HD_TONG_TIEN CHECK (tong_tien >= 0),
                             CONSTRAINT CK_HD_TRANG_THAI CHECK (trang_thai IN (N'Chưa thanh toán', N'Đã thanh toán', N'Đã hủy'))
);
GO

/* Index nay ngan viec tao hai hoa don chua thanh toan cho cung mot ban. */
CREATE UNIQUE INDEX UX_HD_MOI_BAN_MOT_HOA_DON_MO
    ON dbo.HOA_DON(ma_ban)
    WHERE ma_ban IS NOT NULL AND trang_thai = N'Chưa thanh toán';
GO

CREATE INDEX IX_HD_NGAY_LAP ON dbo.HOA_DON(ngay_lap DESC);
GO
CREATE INDEX IX_HD_TRANG_THAI ON dbo.HOA_DON(trang_thai);
GO

/* ================================================================
   9. HOA DON CHI TIET
   - trang_thai_mon phai la NVARCHAR de khop HoaDonChiTiet.java.
   - Mon Chua ra: thanh_tien = 0.
   - Khi mon Da ra: ung dung cap nhat thanh_tien = so_luong * don_gia.
   ================================================================ */
CREATE TABLE dbo.HOA_DON_CHI_TIET (
                                      ma_ct_hoa_don INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                                      so_luong INT NOT NULL,
                                      don_gia DECIMAL(12,2) NOT NULL,
                                      thanh_tien DECIMAL(12,2) NOT NULL CONSTRAINT DF_CTHD_THANH_TIEN DEFAULT (0),
                                      ma_hoa_don INT NOT NULL,
                                      ma_san_pham INT NOT NULL,
                                      trang_thai_mon NVARCHAR(30) NOT NULL CONSTRAINT DF_CTHD_TRANG_THAI DEFAULT N'Chưa ra',
                                      ngay_goi DATETIME2(0) NOT NULL CONSTRAINT DF_CTHD_NGAY_GOI DEFAULT SYSDATETIME(),
                                      ngay_ra_mon DATETIME2(0) NULL,
                                      ghi_chu NVARCHAR(500) NULL,
                                      CONSTRAINT FK_CTHD_HOA_DON FOREIGN KEY (ma_hoa_don) REFERENCES dbo.HOA_DON(ma_hoa_don),
                                      CONSTRAINT FK_CTHD_SAN_PHAM FOREIGN KEY (ma_san_pham) REFERENCES dbo.SAN_PHAM(ma_san_pham),
                                      CONSTRAINT CK_CTHD_SO_LUONG CHECK (so_luong > 0),
                                      CONSTRAINT CK_CTHD_DON_GIA CHECK (don_gia >= 0),
                                      CONSTRAINT CK_CTHD_THANH_TIEN CHECK (thanh_tien >= 0),
                                      CONSTRAINT CK_CTHD_TRANG_THAI CHECK (trang_thai_mon IN (N'Chưa ra', N'Đã ra', N'Đã hủy'))
);
GO

CREATE INDEX IX_CTHD_HOA_DON ON dbo.HOA_DON_CHI_TIET(ma_hoa_don);
GO
CREATE INDEX IX_CTHD_TRANG_THAI_MON ON dbo.HOA_DON_CHI_TIET(trang_thai_mon);
GO

/* ================================================================
   10. NHAT KY HOAT DONG
   ================================================================ */
CREATE TABLE dbo.NHAT_KI_HOAT_DONG (
                                       ma_nhat_ki INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
                                       hanh_dong NVARCHAR(255) NOT NULL,
                                       thoi_gian DATETIME2(0) NOT NULL CONSTRAINT DF_NK_THOI_GIAN DEFAULT SYSDATETIME(),
                                       ma_nhan_vien INT NULL,
                                       CONSTRAINT FK_NK_NHAN_VIEN FOREIGN KEY (ma_nhan_vien)
                                           REFERENCES dbo.NHAN_VIEN(ma_nhan_vien)
);
GO

/* ================================================================
   11. DU LIEU MAU - BAN
   Tat ca ban ban dau de Trong de tranh tinh trang ban co khach
   nhung khong co hoa don dang mo.
   ================================================================ */
INSERT INTO dbo.BAN (ten_ban, khu_vuc, so_ghe, trang_thai, hinh_anh)
VALUES
(N'Bàn 01', N'Tầng 1', 4, N'Trống', N'images/ban/ban-01.jpg'),
(N'Bàn 02', N'Tầng 1', 4, N'Trống', N'images/ban/ban-02.jpg'),
(N'Bàn 03', N'Tầng 2', 4, N'Trống', N'images/ban/ban-03.jpg'),
(N'Bàn 04', N'Tầng 2', 6, N'Trống', N'images/ban/ban-04.jpg'),
(N'Bàn 05', N'Tầng 3', 4, N'Trống', N'images/ban/ban-05.jpg'),
(N'Bàn 06', N'Tầng 3', 6, N'Trống', N'images/ban/ban-06.jpg'),
(N'Bàn 07', N'Tầng 3', 8, N'Trống', N'images/ban/ban-07.jpg');
GO

/* ================================================================
   12. DU LIEU MAU - SAN PHAM
   ================================================================ */
INSERT INTO dbo.SAN_PHAM
(ten_san_pham, gia_tien, anh_san_pham, mo_ta, loai_san_pham, cap_do_cay, don_vi_tinh, trang_thai)
VALUES
(N'Mì cay bò', 45000, N'/image/mi-cay-bo.png', N'Mì cay bò thơm ngon', N'Mì cay', 2, N'Phần', N'Đang bán'),
(N'Mì cay hải sản', 50000, N'/image/mi-hai-san.png', N'Mì cay hải sản tươi ngon', N'Mì cay', 3, N'Phần', N'Đang bán'),
(N'Mì cay xúc xích', 40000, N'/image/mi-xuc-xich.png', N'Mì cay xúc xích', N'Mì cay', 1, N'Phần', N'Đang bán'),
(N'Mì cay thập cẩm', 55000, N'/image/mi-thap-cam.png', N'Mì cay thập cẩm đặc biệt', N'Mì cay', 3, N'Phần', N'Đang bán'),
(N'Mì cay kim chi', 45000, N'/image/mi-kim-chi.png', N'Mì cay kim chi Hàn Quốc', N'Mì cay', 2, N'Phần', N'Đang bán');
GO

/* ================================================================
   13. DU LIEU MAU - KHUYEN MAI
   ================================================================ */
INSERT INTO dbo.KHUYEN_MAI
(ma_code, ten_khuyen_mai, loai_giam, giam_toi_da, gia_tri_giam, ngay_bat_dau, ngay_ket_thuc, trang_thai)
VALUES
('KM_MICAY15', N'Giảm 15% cho hóa đơn mì cay cấp độ', N'Phần trăm', 50000, 15,
 '2026-11-01T00:00:00', '2026-12-31T23:59:59', 1),
('KM_GIAM20K', N'Giảm ngay 20.000đ cho combo đồ uống và mì cay', N'Tiền mặt', 20000, 20000,
 '2026-11-01T00:00:00', '2026-12-31T23:59:59', 1),
('KM_TRUA25', N'Ưu đãi khung giờ trưa giảm 25%', N'Phần trăm', 40000, 25,
 '2026-11-01T00:00:00', '2026-12-15T23:59:59', 1),
('KM_THANG10', N'Chương trình khuyến mãi tháng 10 đã kết thúc', N'Phần trăm', 30000, 10,
 '2026-10-01T00:00:00', '2026-10-31T23:59:59', 0),
('KM_KHAITRUONG', N'Khuyến mãi khai trương đợt đầu đã hết hạn', N'Tiền mặt', 25000, 25000,
 '2026-09-01T00:00:00', '2026-09-30T23:59:59', 0);
GO

/* ================================================================
   14. DU LIEU MAU - VOUCHER
   ================================================================ */
INSERT INTO dbo.VOUCHER
(ma_voucher, ma_code, ten_voucher, loai_giam, gia_tri_giam,
 gia_tri_don_toi_thieu, so_luong, so_luong_da_dung, trang_thai, ngay_ket_thuc)
VALUES
('VC01', 'VC_MICAY10K', N'Giảm 10.000đ cho tô mì cay bất kỳ', N'Tiền mặt', 10000, 40000, 100, 12, 1, '2026-12-31'),
('VC02', 'VC_GIAM15PCT', N'Giảm 15% cho hóa đơn từ 100.000đ', N'Phần trăm', 15, 100000, 50, 8, 1, '2026-12-31'),
('VC03', 'VC_COMBO20K', N'Giảm 20.000đ cho đơn từ 120.000đ', N'Tiền mặt', 20000, 120000, 80, 25, 1, '2026-12-25'),
('VC04', 'VC_VIP25PCT', N'Giảm 25% cho hóa đơn nhóm từ 180.000đ', N'Phần trăm', 25, 180000, 30, 5, 1, '2026-12-31'),
('VC05', 'VC_HETHAN', N'Voucher khai trương đã hết lượt sử dụng', N'Tiền mặt', 15000, 50000, 50, 50, 0, '2026-10-31');
GO

/* ================================================================
   15. VIEW HIEN THI CHI TIET HOA DON
   Mon chua ra se hien 0 dong, dung yeu cau man hinh thanh toan.
   ================================================================ */
CREATE VIEW dbo.vw_HOA_DON_CHI_TIET_HIEN_THI
AS
SELECT
    ct.ma_ct_hoa_don,
    ct.ma_hoa_don,
    ct.ma_san_pham,
    sp.ten_san_pham,
    ct.so_luong,
    ct.don_gia,
    ct.trang_thai_mon,
    CASE
        WHEN ct.trang_thai_mon = N'Đã ra' THEN ct.thanh_tien
        ELSE CONVERT(DECIMAL(12,2), 0)
        END AS thanh_tien_hien_thi,
    ct.ngay_goi,
    ct.ngay_ra_mon,
    ct.ghi_chu
FROM dbo.HOA_DON_CHI_TIET AS ct
         INNER JOIN dbo.SAN_PHAM AS sp ON sp.ma_san_pham = ct.ma_san_pham;
GO

/* ================================================================
   16. CAC TRUY VAN KIEM TRA
   ================================================================ */
SELECT * FROM dbo.BAN ORDER BY ma_ban;
SELECT * FROM dbo.SAN_PHAM ORDER BY ma_san_pham;
SELECT * FROM dbo.KHUYEN_MAI ORDER BY ma_khuyen_mai;
SELECT * FROM dbo.VOUCHER ORDER BY ma_voucher;
SELECT * FROM dbo.HOA_DON ORDER BY ma_hoa_don;
SELECT * FROM dbo.HOA_DON_CHI_TIET ORDER BY ma_ct_hoa_don;
GO

PRINT N'Đã tạo database QuanLyQuanMiCay thành công.';
GO
-- =============================================
-- 17. KIỂM TRA DATABASE SAU KHI TẠO
-- =============================================

USE QuanLyQuanMiCay;
GO

-- Kiểm tra bảng hóa đơn
SELECT * FROM dbo.HOA_DON;

-- Kiểm tra chi tiết hóa đơn
SELECT
    ma_ct_hoa_don,
    ma_hoa_don,
    ma_san_pham,
    so_luong,
    don_gia,
    thanh_tien,
    trang_thai_mon
FROM dbo.HOA_DON_CHI_TIET;

-- Kiểm tra bàn
SELECT * FROM dbo.BAN;

-- Kiểm tra sản phẩm
SELECT * FROM dbo.SAN_PHAM;

PRINT N'Đã tạo database QuanLyQuanMiCay thành công!';
GO
