package com.example.quanlyquanmicay.controller;

import com.example.quanlyquanmicay.util.HibernateConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.IOException;
import java.util.List;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@WebServlet(name = "HoaDonServlet", urlPatterns = {"/hoa-don"})
public class HoaDonServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        Integer maHd = parseInt(request.getParameter("id"));
        Integer maBan = parseInt(request.getParameter("maBan"));
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            if (action == null && maBan != null) {
                Object idDangMo = session.createNativeQuery(
                        "SELECT TOP 1 ma_hoa_don FROM HOA_DON WHERE ma_ban=:maBan AND trang_thai=N'Chưa thanh toán' ORDER BY ma_hoa_don DESC")
                        .setParameter("maBan", maBan).uniqueResult();
                if (idDangMo == null) {
                    response.sendRedirect(request.getContextPath() + "/goi-mon?maBan=" + maBan);
                } else {
                    response.sendRedirect(request.getContextPath() + "/hoa-don?action=chi-tiet&id=" + idDangMo);
                }
                return;
            }
            if ("chi-tiet".equals(action) || "thanh-toan".equals(action)) {
                if (maHd == null) { response.sendRedirect(request.getContextPath() + "/hoa-don"); return; }
                Object[] hd = (Object[]) session.createNativeQuery(
                        "SELECT hd.ma_hoa_don, hd.ma_ban, b.ten_ban, hd.ngay_lap, hd.tong_tien, hd.trang_thai " +
                        "FROM HOA_DON hd LEFT JOIN BAN b ON b.ma_ban=hd.ma_ban WHERE hd.ma_hoa_don=:id")
                        .setParameter("id", maHd).uniqueResult();
                if (hd == null) { response.sendRedirect(request.getContextPath() + "/hoa-don"); return; }
                List<Object[]> dsMon = session.createNativeQuery(
                        "SELECT ct.ma_ct_hoa_don, sp.ten_san_pham, ct.so_luong, ct.don_gia, " +
                        "CASE WHEN ct.trang_thai_mon=N'Chưa ra' THEN 0 ELSE ct.thanh_tien END AS tien_tinh, " +
                        "ct.trang_thai_mon FROM HOA_DON_CHI_TIET ct LEFT JOIN SAN_PHAM sp ON sp.ma_san_pham=ct.ma_san_pham " +
                        "WHERE ct.ma_hoa_don=:id ORDER BY ct.ma_ct_hoa_don")
                        .setParameter("id", maHd).getResultList();
                request.setAttribute("hoaDon", hd);
                request.setAttribute("dsMon", dsMon);
                request.setAttribute("tongThanhToan", hd[4]);
                request.setAttribute("cheDoThanhToan", "thanh-toan".equals(action));
                String bankBin = System.getenv("VIETQR_BANK_BIN");
                String bankAccount = System.getenv("VIETQR_ACCOUNT_NO");
                String accountName = System.getenv("VIETQR_ACCOUNT_NAME");
                if (bankBin != null && bankAccount != null && accountName != null &&
                        !bankBin.trim().isEmpty() && !bankAccount.trim().isEmpty() && !accountName.trim().isEmpty()) {
                    String addInfo = URLEncoder.encode("Thanh toan HD " + maHd, StandardCharsets.UTF_8.name());
                    String encodedName = URLEncoder.encode(accountName.trim(), StandardCharsets.UTF_8.name());
                    String qrUrl = "https://img.vietqr.io/image/" + bankBin.trim() + "-" + bankAccount.trim() +
                            "-compact2.png?amount=" + hd[4] + "&addInfo=" + addInfo + "&accountName=" + encodedName;
                    request.setAttribute("qrUrl", qrUrl);
                }
                request.getRequestDispatcher("/jsp/hoa_don.jsp").forward(request, response);
                return;
            }
            List<Object[]> chuaThanhToan = session.createNativeQuery(
                    "SELECT hd.ma_hoa_don, b.ten_ban, hd.ngay_lap, hd.tong_tien, hd.trang_thai " +
                    "FROM HOA_DON hd LEFT JOIN BAN b ON b.ma_ban=hd.ma_ban WHERE hd.trang_thai=N'Chưa thanh toán' ORDER BY hd.ma_hoa_don DESC").getResultList();
            List<Object[]> daThanhToan = session.createNativeQuery(
                    "SELECT hd.ma_hoa_don, b.ten_ban, hd.ngay_lap, hd.tong_tien, hd.trang_thai " +
                    "FROM HOA_DON hd LEFT JOIN BAN b ON b.ma_ban=hd.ma_ban WHERE hd.trang_thai=N'Đã thanh toán' ORDER BY hd.ma_hoa_don DESC").getResultList();
            request.setAttribute("dsChuaThanhToan", chuaThanhToan);
            request.setAttribute("dsDaThanhToan", daThanhToan);
            request.getRequestDispatcher("/jsp/hoa_don.jsp").forward(request, response);
        } catch (Exception e) {
            throw new ServletException("Không thể tải hóa đơn: " + e.getMessage(), e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        Integer id = parseInt(request.getParameter("id"));
        if (id == null) { response.sendRedirect(request.getContextPath() + "/hoa-don"); return; }
        Transaction tx = null;
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            tx = session.beginTransaction();
            if ("da-ra".equals(action)) {
                Integer ctId = parseInt(request.getParameter("ctId"));
                if (ctId != null) session.createNativeQuery("UPDATE HOA_DON_CHI_TIET SET trang_thai_mon=N'Đã ra' WHERE ma_ct_hoa_don=:ct AND ma_hoa_don=:hd")
                        .setParameter("ct", ctId).setParameter("hd", id).executeUpdate();
                // Cập nhật tổng tiền thực thu, chỉ tính các món đã ra.
                session.createNativeQuery("UPDATE HOA_DON SET tong_tien=(SELECT ISNULL(SUM(thanh_tien),0) FROM HOA_DON_CHI_TIET WHERE ma_hoa_don=:hd AND trang_thai_mon=N'Đã ra') WHERE ma_hoa_don=:hd")
                        .setParameter("hd", id).executeUpdate();
            } else if ("tra-khach".equals(action)) {
                // Chốt tổng tiền chỉ gồm món đã ra; món chưa ra vẫn được lưu và hiển thị 0đ trên bill.
                session.createNativeQuery("UPDATE HOA_DON SET tong_tien=(SELECT ISNULL(SUM(thanh_tien),0) FROM HOA_DON_CHI_TIET WHERE ma_hoa_don=:hd AND trang_thai_mon=N'Đã ra') WHERE ma_hoa_don=:hd")
                        .setParameter("hd", id).executeUpdate();
            } else if ("xac-nhan-thanh-toan".equals(action)) {
                session.createNativeQuery("UPDATE HOA_DON SET trang_thai=N'Đã thanh toán', phuong_thuc_thanh_toan=:pt WHERE ma_hoa_don=:hd AND trang_thai=N'Chưa thanh toán'")
                        .setParameter("pt", request.getParameter("phuongThuc") == null ? "QR/Chuyển khoản" : request.getParameter("phuongThuc"))
                        .setParameter("hd", id).executeUpdate();
                session.createNativeQuery("UPDATE BAN SET trang_thai=N'Trống' WHERE ma_ban=(SELECT ma_ban FROM HOA_DON WHERE ma_hoa_don=:hd)")
                        .setParameter("hd", id).executeUpdate();
            }
            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) tx.rollback();
            throw new ServletException("Không thể cập nhật hóa đơn: " + e.getMessage(), e);
        }
        if ("xac-nhan-thanh-toan".equals(action)) response.sendRedirect(request.getContextPath() + "/hoa-don?action=chi-tiet&id=" + id);
        else response.sendRedirect(request.getContextPath() + "/hoa-don?action=chi-tiet&id=" + id);
    }

    private Integer parseInt(String value) {
        try { return value == null ? null : Integer.valueOf(value); } catch (NumberFormatException e) { return null; }
    }
}
