package com.example.quanlyquanmicay.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "HOA_DON_CHI_TIET")
public class HoaDonChiTiet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ma_ct_hoa_don")
    private Integer maCtHoaDon;

    @Column(name = "ma_hoa_don")
    private Integer maHoaDon;

    @Column(name = "ma_san_pham")
    private Integer maSanPham;

    @Column(name = "so_luong")
    private Integer soLuong;

    @Column(name = "don_gia")
    private BigDecimal donGia;

    @Column(name = "thanh_tien")
    private BigDecimal thanhTien;

    @Column(name = "trang_thai_mon")
    private String trangThaiMon;

    public HoaDonChiTiet() {}
    public Integer getMaCtHoaDon() { return maCtHoaDon; }
    public void setMaCtHoaDon(Integer maCtHoaDon) { this.maCtHoaDon = maCtHoaDon; }
    public Integer getMaHoaDon() { return maHoaDon; }
    public void setMaHoaDon(Integer maHoaDon) { this.maHoaDon = maHoaDon; }
    public Integer getMaSanPham() { return maSanPham; }
    public void setMaSanPham(Integer maSanPham) { this.maSanPham = maSanPham; }
    public Integer getSoLuong() { return soLuong; }
    public void setSoLuong(Integer soLuong) { this.soLuong = soLuong; }
    public BigDecimal getDonGia() { return donGia; }
    public void setDonGia(BigDecimal donGia) { this.donGia = donGia; }
    public BigDecimal getThanhTien() { return thanhTien; }
    public void setThanhTien(BigDecimal thanhTien) { this.thanhTien = thanhTien; }
    public String getTrangThaiMon() { return trangThaiMon; }
    public void setTrangThaiMon(String trangThaiMon) { this.trangThaiMon = trangThaiMon; }
}
