package com.example.quanlyquanmicay.controller;

import com.example.quanlyquanmicay.model.Ban;
import com.example.quanlyquanmicay.model.SanPham;
import com.example.quanlyquanmicay.repository.BanRepository;
import com.example.quanlyquanmicay.util.HibernateConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@WebServlet(name = "GoiMonServlet", urlPatterns = {"/goi-mon"})
public class GoiMonServlet extends HttpServlet {
    private final BanRepository banRepository = new BanRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        try {
            Integer maBan = parseIntOrNull(request.getParameter("maBan"));
            List<Ban> dsBan = safeFindAllBan();

            Ban banHienTai = null;
            if (maBan != null) {
                for (Ban b : dsBan) {
                    if (maBan.equals(b.getMaBan())) {
                        banHienTai = b;
                        break;
                    }
                }
            }
            if (banHienTai == null) {
                response.sendRedirect(request.getContextPath() + "/ban");
                return;
            }

            List<SanPham> dsSanPham = findSanPhamForOrder();
            Map<String, List<SanPham>> menuTheoDanhMuc = new LinkedHashMap<String, List<SanPham>>();

            for (SanPham sp : dsSanPham) {
                String dm = (sp.getLoaiSanPham() == null || sp.getLoaiSanPham().trim().isEmpty())
                        ? "MÌ CAY"
                        : sp.getLoaiSanPham().trim().toUpperCase();
                List<SanPham> listInCat = menuTheoDanhMuc.get(dm);
                if (listInCat == null) {
                    listInCat = new ArrayList<SanPham>();
                    menuTheoDanhMuc.put(dm, listInCat);
                }
                listInCat.add(sp);
            }

            Object hoaDonDangMo = null;
            if (banHienTai != null) {
                try (Session session = HibernateConfig.getFACTORY().openSession()) {
                    hoaDonDangMo = session.createNativeQuery("SELECT TOP 1 ma_hoa_don FROM HOA_DON WHERE ma_ban=:maBan AND trang_thai=N'Chưa thanh toán' ORDER BY ma_hoa_don DESC")
                            .setParameter("maBan", banHienTai.getMaBan()).uniqueResult();
                }
            }
            request.setAttribute("hoaDonDangMo", hoaDonDangMo);
            request.setAttribute("dsBan", dsBan);
            request.setAttribute("banHienTai", banHienTai);
            request.setAttribute("menuTheoDanhMuc", menuTheoDanhMuc);
            request.getRequestDispatcher("/jsp/goi_mon.jsp").forward(request, response);
        } catch (Throwable ex) {
            ex.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().println("<h3>Lỗi tải trang Gọi Món:</h3>");
            response.getWriter().println("<pre>" + ex.getClass().getName() + ": " + ex.getMessage() + "</pre>");
            if (ex.getCause() != null) {
                response.getWriter().println("<pre>Nguyên nhân: " + ex.getCause().getMessage() + "</pre>");
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        Integer maBan = parseIntOrNull(request.getParameter("maBan"));
        String[] maSpArr = request.getParameterValues("maSanPham");
        String[] soLuongArr = request.getParameterValues("soLuong");
        String[] donGiaArr = request.getParameterValues("donGia");

        if (maBan == null || maSpArr == null || maSpArr.length == 0) {
            response.sendRedirect(request.getContextPath() + "/goi-mon" + (maBan != null ? "?maBan=" + maBan : ""));
            return;
        }

        BigDecimal tongTien = BigDecimal.ZERO;
        List<Object[]> items = new ArrayList<Object[]>();
        for (int i = 0; i < maSpArr.length; i++) {
            Integer maSp = parseIntOrNull(maSpArr[i]);
            Integer sl = (soLuongArr != null && i < soLuongArr.length) ? parseIntOrNull(soLuongArr[i]) : 0;
            BigDecimal gia = (donGiaArr != null && i < donGiaArr.length) ? parseBigDecimalOrZero(donGiaArr[i]) : BigDecimal.ZERO;
            if (maSp != null && sl != null && sl > 0) {
                tongTien = tongTien.add(gia.multiply(BigDecimal.valueOf(sl)));
                items.add(new Object[]{maSp, sl, gia});
            }
        }

        if (items.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/goi-mon?maBan=" + maBan);
            return;
        }

        Transaction tx = null;
        int maHoaDonSauKhiLuu = -1;
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            tx = session.beginTransaction();

            Ban ban = session.get(Ban.class, maBan);
            if (ban != null) {
                ban.setTrangThai("Có khách");
                session.merge(ban);
            }

            // Mỗi bàn chỉ có một hóa đơn đang mở. Gọi thêm món sẽ cộng vào hóa đơn đó.
            Object existingId = session.createNativeQuery(
                    "SELECT TOP 1 ma_hoa_don FROM HOA_DON WHERE ma_ban = :maBan AND trang_thai = :trangThai ORDER BY ma_hoa_don DESC")
                    .setParameter("maBan", maBan)
                    .setParameter("trangThai", "Chưa thanh toán")
                    .uniqueResult();

            int maHoaDon;
            if (existingId != null) {
                maHoaDon = ((Number) existingId).intValue();
            } else {
                Object idObj = session.createNativeQuery(
                                "INSERT INTO HOA_DON (ma_ban, ngay_lap, tong_tien, trang_thai) " +
                                        "OUTPUT INSERTED.ma_hoa_don VALUES (:maBan, :ngayLap, :tongTien, :trangThai)")
                        .setParameter("maBan", maBan)
                        .setParameter("ngayLap", LocalDateTime.now(ZoneId.of("Asia/Ho_Chi_Minh")))
                        .setParameter("tongTien", tongTien)
                        .setParameter("trangThai", "Chưa thanh toán")
                        .getSingleResult();
                maHoaDon = ((Number) idObj).intValue();
            }

            for (Object[] it : items) {
                int maSp = (Integer) it[0];
                int sl = (Integer) it[1];
                BigDecimal gia = (BigDecimal) it[2];
                BigDecimal thanhTien = gia.multiply(BigDecimal.valueOf(sl));

                session.createNativeQuery(
                                "INSERT INTO HOA_DON_CHI_TIET (ma_hoa_don, ma_san_pham, so_luong, don_gia, thanh_tien, trang_thai_mon) " +
                                        "VALUES (:maHd, :maSp, :soLuong, :donGia, :thanhTien, N'Chưa ra')"
                        )
                        .setParameter("maHd", maHoaDon)
                        .setParameter("maSp", maSp)
                        .setParameter("soLuong", sl)
                        .setParameter("donGia", gia)
                        .setParameter("thanhTien", thanhTien)
                        .executeUpdate();
            }

            maHoaDonSauKhiLuu = maHoaDon;

            // Tổng tiền chỉ tính các món đã ra; món mới gọi vẫn tạm tính 0đ.
            session.createNativeQuery("UPDATE HOA_DON SET tong_tien=(SELECT ISNULL(SUM(thanh_tien),0) FROM HOA_DON_CHI_TIET WHERE ma_hoa_don=:hd AND trang_thai_mon=N'Đã ra') WHERE ma_hoa_don=:hd")
                    .setParameter("hd", maHoaDon).executeUpdate();

            tx.commit();
        } catch (Exception e) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi lưu hóa đơn: " + e.getMessage());
            doGet(request, response);
            return;
        }

        response.sendRedirect(request.getContextPath() + "/hoa-don?action=chi-tiet&id=" + maHoaDonSauKhiLuu);
    }

    private List<Ban> safeFindAllBan() {
        try {
            List<Ban> list = banRepository.findAll();
            return list != null ? list : Collections.<Ban>emptyList();
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.<Ban>emptyList();
        }
    }

    private List<SanPham> findSanPhamForOrder() {
        try (Session session = HibernateConfig.getFACTORY().openSession()) {
            List<SanPham> dangBan = session.createQuery(
                            "FROM SanPham sp WHERE sp.trangThai = :tt ORDER BY sp.loaiSanPham ASC, sp.maSanPham ASC",
                            SanPham.class
                    )
                    .setParameter("tt", "Đang bán")
                    .getResultList();
            if (dangBan != null && !dangBan.isEmpty()) {
                return dangBan;
            }
            // Nếu trạng thái trong DB dùng chữ khác thì lấy toàn bộ sản phẩm để vẫn hiện món
            return session.createQuery(
                            "FROM SanPham sp ORDER BY sp.loaiSanPham ASC, sp.maSanPham ASC",
                            SanPham.class
                    )
                    .getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.<SanPham>emptyList();
        }
    }

    private Integer parseIntOrNull(String val) {
        try {
            return (val == null || val.trim().isEmpty()) ? null : Integer.parseInt(val.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private BigDecimal parseBigDecimalOrZero(String val) {
        try {
            if (val == null || val.trim().isEmpty()) {
                return BigDecimal.ZERO;
            }
            return new BigDecimal(val.trim());
        } catch (NumberFormatException e) {
            return BigDecimal.ZERO;
        }
    }
}