<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Bàn - Quán Mì Cay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <style>
        .stat-card {
            background: #fff;
            border: 1px solid #e9ecef;
            border-radius: 10px;
            padding: 14px 16px;
        }
        .table-card {
            background: #fff;
            border: 1px solid #e9ecef;
            border-radius: 12px;
            overflow: visible;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            box-shadow: 0 1px 4px rgba(0, 0, 0, 0.04);
        }
        .table-card.is-locked {
            background: #f8fafc;
            border-color: #cbd5e1;
        }
        .table-thumb-wrap {
            position: relative;
            height: 145px;
            border-radius: 12px 12px 0 0;
            overflow: hidden;
            background: #f1f3f5;
        }
        .table-thumb-wrap img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .table-card.is-locked .table-thumb-wrap img {
            filter: grayscale(85%);
            opacity: 0.75;
        }
        .zone-pill {
            position: absolute;
            top: 8px;
            left: 8px;
            background: rgba(15, 23, 42, 0.78);
            color: #fff;
            font-size: 0.72rem;
            font-weight: 600;
            padding: 3px 8px;
            border-radius: 6px;
        }
        .card-top-actions {
            position: absolute;
            top: 8px;
            right: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
            z-index: 5;
        }
        .three-dots-btn {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            border: none;
            background: rgba(255, 255, 255, 0.92);
            color: #1e293b;
            font-weight: 700;
            line-height: 1;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15);
        }
        .three-dots-btn:hover {
            background: #fff;
        }
    </style>
</head>
<body>
<div class="app-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div>
            <div class="sidebar-brand">
                <span>🍜</span>
                <span>Mì Cay Seoul 7 Cấp</span>
            </div>

            <div class="sidebar-admin">
                <span class="admin-avatar">Q</span>
                <div>
                    <div class="fw-semibold small">Quản Lý Cửa Hàng</div>
                    <div class="text-white-50" style="font-size: 0.72rem;">Admin</div>
                </div>
            </div>

            <div class="sidebar-group-title">Tổng quan &amp; Bán hàng</div>
            <ul class="sidebar-menu">
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/HomeServlet"><span>🏠</span><span>Trang chủ</span></a></li>
                <li><a class="sidebar-link active" href="${pageContext.request.contextPath}/ban"><span>🍽️</span><span>Bàn</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/san-pham"><span>🍜</span><span>Sản phẩm</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/hoa-don"><span>🧾</span><span>Hóa đơn</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/hoa-don-chi-tiet"><span>📋</span><span>Chi tiết hóa đơn</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/khach-hang"><span>🙋</span><span>Khách hàng</span></a></li>
            </ul>

            <div class="sidebar-group-title">Ưu đãi, Nhân sự &amp; Hệ thống</div>
            <ul class="sidebar-menu">
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/khuyen-mai"><span>🏷️</span><span>Khuyến mãi</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/voucher"><span>🎟️</span><span>Voucher</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/nhan-vien"><span>👨‍🍳</span><span>Nhân viên</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/quan-ly"><span>👔</span><span>Quản lý</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/nhat-ki"><span>🕒</span><span>Nhật ký hoạt động</span></a></li>
            </ul>
        </div>

        <div class="sidebar-footer">
            <a class="sidebar-link mb-0" href="${pageContext.request.contextPath}/HomeServlet"><span>↪</span><span>Đăng xuất</span></a>
        </div>
    </aside>

    <!-- Nội dung chính -->
    <div class="main-content">
        <header class="topbar">
            <h1 class="topbar-title">Quản Lý Bàn &amp; Gọi Món</h1>
            <div class="d-flex align-items-center gap-2">
                <span class="text-muted small">Xin chào, Admin</span>
                <span class="user-badge">A</span>
            </div>
        </header>

        <main class="content-container">
            <c:if test="${not empty errorMessage}">
                <div class="alert alert-danger py-2" role="alert">
                    <c:out value="${errorMessage}"/>
                </div>
            </c:if>

            <!-- Thống kê nhanh -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="stat-card border-start border-4 border-success">
                        <div class="text-muted small fw-semibold">BÀN TRỐNG</div>
                        <div class="fs-4 fw-bold mt-1">${soBanTrong != null ? soBanTrong : 0}</div>
                        <div class="text-muted" style="font-size: 0.78rem;">Sẵn sàng đón khách</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card border-start border-4 border-danger">
                        <div class="text-muted small fw-semibold">BÀN CÓ KHÁCH</div>
                        <div class="fs-4 fw-bold mt-1">${soBanCoKhach != null ? soBanCoKhach : 0}</div>
                        <div class="text-muted" style="font-size: 0.78rem;">Đang phục vụ</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card border-start border-4 border-secondary">
                        <div class="text-muted small fw-semibold">BÀN ĐANG KHÓA</div>
                        <div class="fs-4 fw-bold mt-1">${soBanKhoa != null ? soBanKhoa : 0}</div>
                        <div class="text-muted" style="font-size: 0.78rem;">Tạm ngưng phục vụ</div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card border-start border-4 border-primary">
                        <div class="text-muted small fw-semibold">TỔNG SỐ BÀN</div>
                        <div class="fs-4 fw-bold mt-1">${tongSoBan != null ? tongSoBan : 0}</div>
                        <div class="text-muted" style="font-size: 0.78rem;">Toàn hệ thống</div>
                    </div>
                </div>
            </div>

            <!-- Form thêm bàn mới -->
            <section class="section-panel mb-4">
                <h2 class="h6 fw-bold mb-3">Thêm Bàn mới</h2>
                <form method="post" action="${pageContext.request.contextPath}/ban" class="row g-3">
                    <div class="col-md-3">
                        <label for="txt_tenBan" class="form-label small fw-semibold">Tên bàn <span class="text-danger">*</span></label>
                        <input type="text" id="txt_tenBan" name="txt_tenBan"
                               class="form-control form-control-sm"
                               placeholder="VD: Bàn 08"
                               value="<c:out value='${param.txt_tenBan}'/>">
                    </div>

                    <div class="col-md-2">
                        <label for="sel_khuVuc" class="form-label small fw-semibold">Khu vực</label>
                        <select id="sel_khuVuc" name="sel_khuVuc" class="form-select form-select-sm">
                            <option value="Tầng 1">Tầng 1</option>
                            <option value="Tầng 2">Tầng 2</option>
                            <option value="Tầng 3">Tầng 3</option>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label for="txt_soGhe" class="form-label small fw-semibold">Số ghế</label>
                        <input type="number" min="1" id="txt_soGhe" name="txt_soGhe"
                               class="form-control form-control-sm"
                               value="${not empty param.txt_soGhe ? param.txt_soGhe : '4'}">
                    </div>

                    <div class="col-md-2">
                        <label for="sel_trangThai" class="form-label small fw-semibold">Trạng thái</label>
                        <select id="sel_trangThai" name="sel_trangThai" class="form-select form-select-sm">
                            <option value="Trống">Trống</option>
                            <option value="Có khách">Có khách</option>
                            <option value="Khóa bàn">Khóa bàn</option>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <label for="txt_hinhAnh" class="form-label small fw-semibold">Đường dẫn hình ảnh</label>
                        <div class="input-group input-group-sm">
                            <input type="text" id="txt_hinhAnh" name="txt_hinhAnh"
                                   class="form-control"
                                   placeholder="images/ban/ban-08.jpg"
                                   value="<c:out value='${param.txt_hinhAnh}'/>">
                            <button type="submit" class="btn btn-order-blue">+ Thêm</button>
                        </div>
                    </div>
                </form>
            </section>

            <!-- Danh sách bàn + tìm kiếm + lọc khu vực -->
            <section class="section-panel">
                <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                    <h2 class="h6 fw-bold mb-0">Danh sách trạng thái bàn</h2>

                    <form method="get" action="${pageContext.request.contextPath}/ban" class="d-flex flex-wrap gap-2">
                        <select name="khuVuc" class="form-select form-select-sm" style="width: auto;">
                            <option value="ALL" ${khuVuc == 'ALL' ? 'selected' : ''}>-- Tất cả khu vực --</option>
                            <c:forEach var="kv" items="${dsKhuVuc}">
                                <option value="<c:out value='${kv}'/>" ${khuVuc == kv ? 'selected' : ''}>
                                    <c:out value="${kv}"/>
                                </option>
                            </c:forEach>
                        </select>

                        <input type="text" name="keyword" class="form-control form-control-sm"
                               style="width: 200px;"
                               placeholder="Nhập số bàn (VD: Bàn 01)"
                               value="<c:out value='${keyword}'/>">

                        <button type="submit" class="btn btn-sm btn-primary">🔍 Tìm kiếm</button>
                        <c:if test="${not empty keyword || (not empty khuVuc && khuVuc != 'ALL')}">
                            <a href="${pageContext.request.contextPath}/ban" class="btn btn-sm btn-outline-secondary">Xóa lọc</a>
                        </c:if>
                    </form>
                </div>

                <div class="row g-3">
                    <c:forEach var="b" items="${dsBan}">
                        <c:set var="imgSrc" value="${empty b.hinhAnh ? 'images/ban/ban-default.jpg' : b.hinhAnh}"/>
                        <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                            <div class="table-card ${b.trangThai == 'Khóa bàn' ? 'is-locked' : ''}">
                                <div>
                                    <div class="table-thumb-wrap">
                                        <img src="${pageContext.request.contextPath}/${imgSrc}"
                                             alt="<c:out value='${b.tenBan}'/>"
                                             onerror="this.onerror=null;this.src='data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22220%22><rect width=%22400%22 height=%22220%22 fill=%22%23e2e8f0%22/><text x=%2250%25%22 y=%2250%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 fill=%22%23475569%22 font-family=%22Arial%22 font-size=%2220%22>Ban An - Mi Cay</text></svg>';">

                                        <span class="zone-pill"><c:out value="${b.khuVuc}"/></span>

                                        <!-- Badge trạng thái + Nút 3 chấm sửa trạng thái ở góc bàn -->
                                        <div class="card-top-actions">
                                            <c:choose>
                                                <c:when test="${b.trangThai == 'Có khách'}">
                                                    <span class="badge rounded-pill bg-danger">Có khách</span>
                                                </c:when>
                                                <c:when test="${b.trangThai == 'Khóa bàn'}">
                                                    <span class="badge rounded-pill bg-secondary">🔒 Đang khóa</span>
                                                </c:when>
                                                <c:otherwise>
                                                    <span class="badge rounded-pill bg-success">Trống</span>
                                                </c:otherwise>
                                            </c:choose>

                                            <div class="dropdown">
                                                <button class="three-dots-btn" type="button" data-bs-toggle="dropdown" aria-expanded="false" title="Đổi trạng thái bàn">
                                                    ⋮
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                                                    <li><h6 class="dropdown-header small">Đổi trạng thái bàn</h6></li>
                                                    <li>
                                                        <a class="dropdown-item small"
                                                           href="${pageContext.request.contextPath}/ban?action=status&id=${b.maBan}&trangThai=Tr%E1%BB%91ng&khuVuc=${khuVuc}&keyword=${keyword}">
                                                            🟢 Trống
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a class="dropdown-item small"
                                                           href="${pageContext.request.contextPath}/ban?action=status&id=${b.maBan}&trangThai=C%C3%B3%20kh%C3%A1ch&khuVuc=${khuVuc}&keyword=${keyword}">
                                                            🔴 Có khách
                                                        </a>
                                                    </li>
                                                    <li><hr class="dropdown-divider"></li>
                                                    <li>
                                                        <a class="dropdown-item small text-secondary"
                                                           href="${pageContext.request.contextPath}/ban?action=status&id=${b.maBan}&trangThai=Kh%C3%B3a%20b%C3%A0n&khuVuc=${khuVuc}&keyword=${keyword}">
                                                            🔒 Khóa bàn
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="p-3 pb-2">
                                        <div class="fw-bold">
                                            <c:out value="${b.tenBan}"/>
                                            <span class="text-muted fw-normal small">(${b.soGhe} ghế)</span>
                                        </div>
                                        <div class="text-muted small mt-1">
                                            <c:choose>
                                                <c:when test="${b.trangThai == 'Có khách'}">
                                                    Đang phục vụ khách
                                                </c:when>
                                                <c:when test="${b.trangThai == 'Khóa bàn'}">
                                                    Bàn đang khóa, tạm ngưng nhận khách
                                                </c:when>
                                                <c:otherwise>
                                                    Sẵn sàng đón khách
                                                </c:otherwise>
                                            </c:choose>
                                        </div>
                                    </div>
                                </div>

                                <!-- Nút hành động dưới mỗi thẻ bàn -->
                                <div class="p-3 pt-1">
                                    <c:choose>
                                        <c:when test="${b.trangThai == 'Khóa bàn'}">
                                            <a href="${pageContext.request.contextPath}/ban?action=status&id=${b.maBan}&trangThai=Tr%E1%BB%91ng&khuVuc=${khuVuc}&keyword=${keyword}"
                                               class="btn btn-sm btn-outline-secondary w-100 fw-semibold">
                                                🔓 Mở khóa bàn
                                            </a>
                                        </c:when>
                                        <c:when test="${b.trangThai == 'Có khách'}">
                                            <div class="d-flex gap-2">
                                                <a href="${pageContext.request.contextPath}/goi-mon?maBan=${b.maBan}"
                                                   class="btn btn-sm btn-primary flex-grow-1">
                                                    🍜 Gọi món
                                                </a>
                                                <a href="${pageContext.request.contextPath}/hoa-don?maBan=${b.maBan}"
                                                   class="btn btn-sm btn-pay-red">
                                                    ✓ Trả khách
                                                </a>
                                            </div>
                                        </c:when>
                                        <c:otherwise>
                                            <div class="d-flex gap-2">
                                                <a href="${pageContext.request.contextPath}/ban?action=dat-ban&id=${b.maBan}"
                                                   class="btn btn-sm btn-order-blue flex-grow-1">
                                                    🍽️ Đặt bàn
                                                </a>
                                                <a href="${pageContext.request.contextPath}/ban?action=status&id=${b.maBan}&trangThai=Kh%C3%B3a%20b%C3%A0n&khuVuc=${khuVuc}&keyword=${keyword}"
                                                   class="btn btn-sm btn-outline-secondary"
                                                   title="Khóa bàn này">
                                                    🔒 Khóa
                                                </a>
                                            </div>
                                        </c:otherwise>
                                    </c:choose>
                                </div>
                            </div>
                        </div>
                    </c:forEach>

                    <c:if test="${empty dsBan}">
                        <div class="col-12">
                            <div class="text-center text-muted py-4">
                                Không tìm thấy bàn nào phù hợp.
                            </div>
                        </div>
                    </c:if>
                </div>
            </section>
        </main>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>