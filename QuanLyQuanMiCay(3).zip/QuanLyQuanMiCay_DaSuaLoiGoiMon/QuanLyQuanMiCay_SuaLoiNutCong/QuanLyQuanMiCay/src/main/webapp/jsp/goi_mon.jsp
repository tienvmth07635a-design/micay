<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gọi Món - Mì Cay Seoul 7 Cấp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
            padding-bottom: 92px;
        }
        .order-shell {
            max-width: 760px;
            margin: 0 auto;
            background: #f8f9fa;
            min-height: 100vh;
        }
        .sticky-top-bar {
            position: sticky;
            top: 0;
            z-index: 1020;
            background: #ffffff;
            border-bottom: 1px solid #eceff3;
        }
        .circle-icon-btn {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            border: 1px solid #e9ecef;
            background: #f8f9fa;
            color: #1e293b;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            font-weight: 600;
        }
        .search-pill {
            background: #f1f3f5;
            border-radius: 10px;
            padding: 6px 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .search-pill input {
            border: none;
            background: transparent;
            outline: none;
            width: 100%;
            font-size: 0.92rem;
        }
        .cat-tabs {
            display: flex;
            overflow-x: auto;
            gap: 20px;
            padding: 10px 16px 0 16px;
            scrollbar-width: none;
        }
        .cat-tabs::-webkit-scrollbar {
            display: none;
        }
        .cat-tab {
            white-space: nowrap;
            text-decoration: none;
            color: #334155;
            font-weight: 700;
            font-size: 0.85rem;
            padding-bottom: 10px;
            border-bottom: 2.5px solid transparent;
            text-transform: uppercase;
        }
        .cat-tab.active, .cat-tab:hover {
            color: #f59e0b;
            border-bottom-color: #f59e0b;
        }
        .section-heading {
            font-size: 0.95rem;
            font-weight: 800;
            color: #1e293b;
            text-transform: uppercase;
            margin: 18px 0 10px 0;
        }
        .food-card {
            background: #ffffff;
            border-radius: 14px;
            padding: 12px;
            margin-bottom: 12px;
            box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
        }
        .food-thumb {
            width: 76px;
            height: 76px;
            border-radius: 12px;
            object-fit: cover;
            flex-shrink: 0;
            background: #f1f5f9;
        }
        .food-info {
            flex: 1;
            min-width: 0;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            min-height: 72px;
        }
        .food-name {
            font-weight: 700;
            font-size: 0.98rem;
            color: #1e293b;
            line-height: 1.3;
        }
        .food-sub {
            font-size: 0.78rem;
            color: #64748b;
            margin-top: 2px;
        }
        .food-price {
            color: #f59e0b;
            font-weight: 700;
            font-size: 0.95rem;
            margin-top: 6px;
        }
        .btn-plus-orange {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            border: none;
            background: #f59e0b;
            color: #ffffff;
            font-size: 1.2rem;
            font-weight: 700;
            line-height: 1;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            box-shadow: 0 2px 6px rgba(245, 158, 11, 0.35);
        }
        .btn-plus-orange:hover {
            background: #d97706;
        }
        .qty-stepper {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #fff7ed;
            border: 1px solid #fed7aa;
            border-radius: 20px;
            padding: 2px 6px;
        }
        .qty-btn {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            border: none;
            background: #f59e0b;
            color: #fff;
            font-weight: 700;
            line-height: 1;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .bottom-cart-bar {
            position: fixed;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 1030;
            background: #ffffff;
            border-top: 1px solid #e9ecef;
            padding: 10px 16px;
            box-shadow: 0 -4px 14px rgba(15, 23, 42, 0.06);
        }
        .bottom-cart-inner {
            max-width: 760px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .mini-thumbs {
            display: flex;
            align-items: center;
        }
        .mini-thumbs img {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #fff;
            box-shadow: 0 1px 4px rgba(0,0,0,0.15);
            margin-left: -10px;
        }
        .mini-thumbs img:first-child {
            margin-left: 0;
        }
        .btn-confirm-bar {
            flex: 1;
            background: #f59e0b;
            color: #ffffff;
            border: none;
            border-radius: 10px;
            padding: 11px 16px;
            font-weight: 700;
            font-size: 0.96rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 3px 10px rgba(245, 158, 11, 0.35);
        }
        .btn-confirm-bar:disabled {
            background: #cbd5e1;
            box-shadow: none;
        }
    </style>
</head>
<body>
<div class="order-shell">
    <div class="sticky-top-bar">
        <div class="d-flex align-items-center justify-content-between px-3 pt-3 pb-2">
            <a href="${pageContext.request.contextPath}/ban" class="circle-icon-btn" title="Quay lại danh sách bàn">
                ✕
            </a>

            <div class="text-center">
                <div class="fw-bold fs-6">🍜 Mì Cay Seoul 7 Cấp</div>
                <div class="small text-muted">
                    Đang gọi món cho:
                    <span class="fw-bold text-warning">
                        <c:out value="${banHienTai != null ? banHienTai.tenBan : 'Chưa chọn bàn'}"/>
                    </span>
                </div>
            </div>

            <c:if test="${not empty hoaDonDangMo}">
                <a href="${pageContext.request.contextPath}/hoa-don?action=chi-tiet&id=${hoaDonDangMo}"
                   class="btn btn-outline-primary btn-sm ms-2">🧾 Hóa đơn tại bàn</a>
            </c:if>
            <a href="${pageContext.request.contextPath}/hoa-don" class="circle-icon-btn" title="Xem hóa đơn">
                🧾
            </a>
        </div>

        <div class="px-3 pb-2 d-flex align-items-center gap-2">
            <a href="${pageContext.request.contextPath}/ban" class="circle-icon-btn" style="border-radius: 10px; color: #f59e0b;">
                🏠
            </a>
            <div class="search-pill flex-grow-1">
                <span class="text-muted">🔍</span>
                <input type="text" id="searchFoodInput" placeholder="Bạn muốn tìm món gì ?" onkeyup="filterFoods()">
            </div>
        </div>

        <div class="cat-tabs" id="catTabs">
            <c:forEach var="entry" items="${menuTheoDanhMuc}" varStatus="st">
                <a href="#cat-${st.index}" class="cat-tab ${st.first ? 'active' : ''}" onclick="setActiveTab(this)">
                    <c:out value="${entry.key}"/>
                </a>
            </c:forEach>
        </div>
    </div>

    <div class="px-3 pt-1">
        <c:if test="${not empty errorMessage}">
            <div class="alert alert-danger mt-3 py-2 small">
                <c:out value="${errorMessage}"/>
            </div>
        </c:if>

        <c:forEach var="entry" items="${menuTheoDanhMuc}" varStatus="st">
            <div class="category-block" id="cat-${st.index}">
                <div class="section-heading"><c:out value="${entry.key}"/></div>

                <c:forEach var="sp" items="${entry.value}">
                    <c:set var="spImg" value="${empty sp.anhSanPham ? 'images/mon/default.jpg' : sp.anhSanPham}"/>
                    <c:set var="giaSo" value="${sp.giaTien != null ? sp.giaTien : 0}"/>
                    <div class="food-card" data-name="<c:out value='${sp.tenSanPham}'/>">
                        <img class="food-thumb"
                             src="${pageContext.request.contextPath}/${spImg}"
                             alt="<c:out value='${sp.tenSanPham}'/>"
                             onerror="this.onerror=null;this.src='data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22160%22 height=%22160%22><rect width=%22160%22 height=%22160%22 fill=%22%23fff7ed%22/><text x=%2250%25%22 y=%2252%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 fill=%22%23f59e0b%22 font-family=%22Arial%22 font-size=%2228%22>🍜</text></svg>';">

                        <div class="food-info">
                            <div>
                                <div class="food-name">
                                    <c:out value="${sp.tenSanPham}"/>
                                    <c:if test="${sp.capDoCay > 0}">
                                        <span class="badge bg-danger-subtle text-danger ms-1" style="font-size: 0.7rem;">
                                            🌶️ Cấp ${sp.capDoCay}
                                        </span>
                                    </c:if>
                                </div>
                                <c:if test="${not empty sp.moTa}">
                                    <div class="food-sub"><c:out value="${sp.moTa}"/></div>
                                </c:if>
                            </div>

                            <div class="d-flex align-items-center justify-content-between">
                                <div class="food-price">
                                    <fmt:formatNumber value="${giaSo}" pattern="#,##0"/>
                                </div>

                                <div id="ctrl-${sp.maSanPham}" data-id="${sp.maSanPham}" data-name="<c:out value='${sp.tenSanPham}'/>" data-price="${giaSo}" data-img="${pageContext.request.contextPath}/${spImg}">
                                    <button type="button"
                                            class="btn-plus-orange js-add-item"
                                            data-id="${sp.maSanPham}"
                                            data-name="<c:out value='${sp.tenSanPham}'/>"
                                            data-price="${giaSo}"
                                            data-img="${pageContext.request.contextPath}/${spImg}"
                                            aria-label="Thêm ${sp.tenSanPham} vào giỏ">
                                        +
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </c:forEach>

        <c:if test="${empty menuTheoDanhMuc}">
            <div class="text-center text-muted py-5">
                Chưa có món nào đang bán trong thực đơn. Vui lòng thêm hoặc bật trạng thái <b>Đang bán</b> ở mục <b>Sản phẩm</b>.
            </div>
        </c:if>
    </div>
</div>

<div class="bottom-cart-bar">
    <div class="bottom-cart-inner">
        <div class="mini-thumbs" id="miniThumbs"></div>
        <button type="button" class="btn-confirm-bar" id="btnOpenCart" disabled data-bs-toggle="modal" data-bs-target="#cartModal">
            <span id="bottomTotalPrice">0</span>
            <span>Xem và xác nhận (<span id="bottomTotalQty">0</span>)</span>
        </button>
    </div>
</div>

<div class="modal fade" id="cartModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content rounded-4">
            <div class="modal-header">
                <h5 class="modal-title fw-bold fs-6">
                    Xác nhận gọi món - <span class="text-warning"><c:out value="${banHienTai != null ? banHienTai.tenBan : ''}"/></span>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form method="post" action="${pageContext.request.contextPath}/goi-mon">
                <input type="hidden" name="maBan" value="${banHienTai != null ? banHienTai.maBan : ''}">
                <div class="modal-body" id="cartModalBody"></div>
                <div class="modal-footer justify-content-between">
                    <div>
                        <div class="small text-muted">Tổng thanh toán tạm tính</div>
                        <div class="fw-bold fs-5 text-warning" id="modalTotalPrice">0 đ</div>
                    </div>
                    <button type="submit" class="btn fw-bold text-white px-4" style="background:#f59e0b;">
                        ✓ Xác nhận gọi món
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function () {
    "use strict";

    // Lưu giỏ hàng tạm trên trình duyệt, chỉ gửi xuống server khi xác nhận.
    var cart = {};
    var fallbackSvg = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='80' height='80'><rect width='80' height='80' fill='%23fff7ed'/><text x='50%' y='54%' dominant-baseline='middle' text-anchor='middle' font-size='24'>🍜</text></svg>";

    function formatMoney(value) {
        var number = Number(value);
        if (!isFinite(number)) number = 0;
        return Math.round(number).toLocaleString('vi-VN');
    }

    function makeButton(text, className, id, delta) {
        var button = document.createElement('button');
        button.type = 'button';
        button.className = className;
        button.textContent = text;
        button.setAttribute('data-id', String(id));
        if (delta !== null) button.setAttribute('data-delta', String(delta));
        return button;
    }

    function addItem(id, name, price, img) {
        id = String(id || '').trim();
        price = Number(price);
        if (!id || !isFinite(price) || price < 0) {
            console.error('Không thể thêm món: mã hoặc giá không hợp lệ.', id, price);
            return;
        }

        if (!cart[id]) {
            cart[id] = {
                id: id,
                name: name || 'Món ăn',
                price: price,
                img: img || fallbackSvg,
                qty: 0
            };
        }
        cart[id].qty += 1;
        renderItemControl(id);
        renderBottomBar();
    }

    function changeQty(id, delta) {
        id = String(id || '');
        delta = parseInt(delta, 10);
        if (!cart[id] || !isFinite(delta)) return;

        cart[id].qty += delta;
        if (cart[id].qty <= 0) delete cart[id];

        renderItemControl(id);
        renderBottomBar();
    }

    function renderItemControl(id) {
        var box = document.getElementById('ctrl-' + id);
        if (!box) return;

        box.innerHTML = '';
        var item = cart[id];

        if (!item) {
            var plus = document.createElement('button');
            plus.type = 'button';
            plus.className = 'btn-plus-orange js-add-item';
            plus.setAttribute('data-id', box.getAttribute('data-id'));
            plus.setAttribute('data-name', box.getAttribute('data-name'));
            plus.setAttribute('data-price', box.getAttribute('data-price'));
            plus.setAttribute('data-img', box.getAttribute('data-img'));
            plus.setAttribute('aria-label', 'Thêm món vào giỏ');
            plus.textContent = '+';
            box.appendChild(plus);
            return;
        }

        var stepper = document.createElement('div');
        stepper.className = 'qty-stepper';
        stepper.appendChild(makeButton('−', 'qty-btn js-change-qty', id, -1));

        var quantity = document.createElement('span');
        quantity.className = 'fw-bold small px-1';
        quantity.textContent = String(item.qty);
        stepper.appendChild(quantity);

        stepper.appendChild(makeButton('+', 'qty-btn js-change-qty', id, 1));
        box.appendChild(stepper);
    }

    function renderBottomBar() {
        var items = Object.keys(cart).map(function (key) { return cart[key]; });
        var totalQty = 0;
        var totalPrice = 0;

        items.forEach(function (item) {
            totalQty += item.qty;
            totalPrice += item.qty * item.price;
        });

        document.getElementById('bottomTotalPrice').textContent = formatMoney(totalPrice) + ' đ';
        document.getElementById('bottomTotalQty').textContent = String(totalQty);
        document.getElementById('btnOpenCart').disabled = totalQty === 0;

        var thumbs = document.getElementById('miniThumbs');
        thumbs.innerHTML = '';
        items.slice(0, 3).forEach(function (item) {
            var image = document.createElement('img');
            image.src = item.img || fallbackSvg;
            image.alt = item.name;
            image.onerror = function () {
                this.onerror = null;
                this.src = fallbackSvg;
            };
            thumbs.appendChild(image);
        });

        renderModalBody();
    }

    function addHiddenInput(parent, name, value) {
        var input = document.createElement('input');
        input.type = 'hidden';
        input.name = name;
        input.value = String(value);
        parent.appendChild(input);
    }

    function renderModalBody() {
        var body = document.getElementById('cartModalBody');
        var totalElement = document.getElementById('modalTotalPrice');
        if (!body || !totalElement) return;

        body.innerHTML = '';
        var items = Object.keys(cart).map(function (key) { return cart[key]; });

        if (items.length === 0) {
            var empty = document.createElement('div');
            empty.className = 'text-center text-muted py-4';
            empty.textContent = 'Chưa có món nào được chọn.';
            body.appendChild(empty);
            totalElement.textContent = '0 đ';
            return;
        }

        var total = 0;
        items.forEach(function (item) {
            var row = document.createElement('div');
            row.className = 'd-flex align-items-center justify-content-between py-2 border-bottom';

            addHiddenInput(row, 'maSanPham', item.id);
            addHiddenInput(row, 'soLuong', item.qty);
            addHiddenInput(row, 'donGia', item.price);

            var info = document.createElement('div');
            info.className = 'pe-2';

            var name = document.createElement('div');
            name.className = 'fw-semibold';
            name.textContent = item.name;

            var price = document.createElement('div');
            price.className = 'small text-warning fw-semibold';
            price.textContent = formatMoney(item.price) + ' đ';

            info.appendChild(name);
            info.appendChild(price);

            var stepper = document.createElement('div');
            stepper.className = 'qty-stepper';
            stepper.appendChild(makeButton('−', 'qty-btn js-change-qty', item.id, -1));

            var quantity = document.createElement('span');
            quantity.className = 'fw-bold small px-1';
            quantity.textContent = String(item.qty);
            stepper.appendChild(quantity);
            stepper.appendChild(makeButton('+', 'qty-btn js-change-qty', item.id, 1));

            row.appendChild(info);
            row.appendChild(stepper);
            body.appendChild(row);

            total += item.qty * item.price;
        });

        totalElement.textContent = formatMoney(total) + ' đ';
    }

    // Bắt sự kiện trên document để vẫn hoạt động khi các nút được vẽ lại.
    document.addEventListener('click', function (event) {
        var target = event.target;
        while (target && target !== document && !target.classList) {
            target = target.parentNode;
        }
        if (!target || !target.classList) return;

        if (target.classList.contains('js-add-item')) {
            event.preventDefault();
            addItem(
                target.getAttribute('data-id'),
                target.getAttribute('data-name'),
                target.getAttribute('data-price'),
                target.getAttribute('data-img')
            );
            return;
        }

        if (target.classList.contains('js-change-qty')) {
            event.preventDefault();
            changeQty(
                target.getAttribute('data-id'),
                target.getAttribute('data-delta')
            );
        }
    });

    window.filterFoods = function () {
        var input = document.getElementById('searchFoodInput');
        var keyword = input ? input.value.trim().toLowerCase() : '';

        document.querySelectorAll('.category-block').forEach(function (block) {
            var visibleCount = 0;
            block.querySelectorAll('.food-card').forEach(function (card) {
                var name = (card.getAttribute('data-name') || '').toLowerCase();
                var matched = name.indexOf(keyword) !== -1;
                card.style.display = matched ? 'flex' : 'none';
                if (matched) visibleCount++;
            });
            block.style.display = visibleCount > 0 ? 'block' : 'none';
        });
    };

    window.setActiveTab = function (element) {
        document.querySelectorAll('.cat-tab').forEach(function (tab) {
            tab.classList.remove('active');
        });
        element.classList.add('active');
    };

    var form = document.querySelector('#cartModal form');
    if (form) {
        form.addEventListener('submit', function (event) {
            var selected = Object.keys(cart);
            if (selected.length === 0) {
                event.preventDefault();
                alert('Bạn chưa chọn món nào. Vui lòng nhấn dấu + để thêm món.');
                return;
            }
            // Đảm bảo các input ẩn trong modal đã được tạo trước khi submit.
            renderModalBody();
        });
    }

    // Khởi tạo giao diện giỏ hàng khi trang tải xong.
    renderBottomBar();
})();
</script>
</body>
</html>