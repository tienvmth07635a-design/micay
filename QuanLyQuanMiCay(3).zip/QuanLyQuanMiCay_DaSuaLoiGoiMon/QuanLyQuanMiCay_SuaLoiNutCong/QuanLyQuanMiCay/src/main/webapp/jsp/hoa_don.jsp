<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Quản lý hóa đơn - Mì Cay Seoul 7 Cấp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
    <style>
        body{background:#f5f6fa;color:#263238}.main-content{min-width:0}.wrap{max-width:1180px;margin:28px auto;padding:0 20px;width:100%}
        .panel{background:#fff;border:1px solid #e8eaf0;border-radius:14px;padding:22px;box-shadow:0 3px 14px #172b4d0a}
        .muted-item{color:#adb5bd!important;background:#fafafa}.bill{max-width:760px;margin:auto}.bill-head{text-align:center;border-bottom:1px dashed #bbb;padding-bottom:16px;margin-bottom:18px}
        .money{font-variant-numeric:tabular-nums}.qr{width:190px;height:190px;object-fit:contain;border:1px solid #eee;border-radius:8px;padding:6px;background:white}
        @media(max-width:850px){.sidebar{width:190px}.content-container{padding:12px}}
        @media print{.no-print,.sidebar,.topbar{display:none!important}body{background:white}.app-wrapper{display:block}.main-content{display:block}.wrap{margin:0;max-width:none;padding:0}.panel{border:0;box-shadow:none}}
    </style>
</head>
<body>
<div class="app-wrapper">
    <aside class="sidebar no-print">
        <div>
            <div class="sidebar-brand"><span>🍜</span><span>Mì Cay Seoul 7 Cấp</span></div>
            <div class="sidebar-admin"><span class="admin-avatar">Q</span><div><div class="fw-semibold small">Quản Lý Cửa Hàng</div><div class="text-white-50" style="font-size:.72rem">Admin</div></div></div>
            <div class="sidebar-group-title">Tổng quan &amp; Bán hàng</div>
            <ul class="sidebar-menu">
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/HomeServlet"><span>🏠</span><span>Trang chủ</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/ban"><span>🍽️</span><span>Bàn</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/san-pham"><span>🍜</span><span>Sản phẩm</span></a></li>
                <li><a class="sidebar-link active" href="${pageContext.request.contextPath}/hoa-don"><span>🧾</span><span>Hóa đơn</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/hoa-don-chi-tiet"><span>📋</span><span>Chi tiết hóa đơn</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/khach-hang"><span>🙋</span><span>Khách hàng</span></a></li>
            </ul>
            <div class="sidebar-group-title">Ưu đãi, Nhân sự &amp; Hệ thống</div>
            <ul class="sidebar-menu">
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/khuyen-mai"><span>🏷️</span><span>Khuyến mãi</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/voucher"><span>🎟️</span><span>Voucher</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/nhan-vien"><span>👨‍🍳</span><span>Nhân viên</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/quan-ly"><span>👔</span><span>Quản lý</span></a></li>
                <li><a class="sidebar-link" href="${pageContext.request.contextPath}/nhat-ki"><span>🕒</span><span>Nhật ký hoạt động</span></a></li>
            </ul>
        </div>
        <div class="sidebar-footer"><a class="sidebar-link mb-0" href="${pageContext.request.contextPath}/HomeServlet"><span>↪</span><span>Trang chủ</span></a></div>
    </aside>
    <div class="main-content">
        <header class="topbar"><h1 class="topbar-title">Quản lý hóa đơn</h1><div class="d-flex align-items-center gap-2"><span class="text-muted small">Xin chào, Admin</span><span class="user-badge">A</span></div></header>
<div class="wrap">
<c:choose>
    <c:when test="${not empty hoaDon}">
        <div class="panel bill">
            <div class="d-flex justify-content-between align-items-center mb-3 no-print">
                <a class="btn btn-outline-secondary btn-sm" href="${pageContext.request.contextPath}/hoa-don">← Quản lý hóa đơn</a>
                <c:if test="${hoaDon[5] == 'Chưa thanh toán'}">
                    <a class="btn btn-primary btn-sm" href="${pageContext.request.contextPath}/goi-mon?maBan=${hoaDon[1]}">🍜 Gọi thêm món</a>
                </c:if>
                <c:if test="${hoaDon[5] == 'Đã thanh toán'}">
                    <button class="btn btn-dark btn-sm" onclick="window.print()">🖨 In hóa đơn</button>
                </c:if>
            </div>
            <div class="bill-head">
                <h3 class="fw-bold">MÌ CAY SEOUL 7 CẤP</h3><div>HÓA ĐƠN THANH TOÁN</div>
                <div class="text-muted small">Mã hóa đơn: <strong>#${hoaDon[0]}</strong></div>
                <div class="text-muted small">${hoaDon[2]} · ${hoaDon[3]}</div>
                <span class="badge ${hoaDon[5] == 'Đã thanh toán' ? 'text-bg-success' : 'text-bg-warning'} mt-2">${hoaDon[5]}</span>
            </div>
            <div class="d-flex justify-content-between mb-3"><span>Bàn</span><strong>${hoaDon[2]}</strong></div>
            <div class="d-flex flex-wrap gap-2 align-items-center justify-content-between mb-2 no-print">
                <h6 class="fw-bold mb-0">Danh sách món</h6>
                <div class="btn-group btn-group-sm">
                    <button type="button" class="btn btn-outline-success" onclick="locMon('all')">Tất cả món</button>
                    <button type="button" class="btn btn-outline-success" onclick="locMon('served')">Đơn hàng đã ra</button>
                    <button type="button" class="btn btn-outline-secondary" onclick="locMon('waiting')">Đơn hàng chưa ra</button>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead><tr><th>Món</th><th class="text-center">SL</th><th class="text-end">Đơn giá</th><th class="text-center">Trạng thái</th><th class="text-end">Thành tiền</th></tr></thead>
                    <tbody>
                    <c:forEach items="${dsMon}" var="m">
                        <tr data-mon-state="${m[5] == 'Đã ra' ? 'served' : 'waiting'}" class="${m[5] == 'Chưa ra' ? 'muted-item' : ''}">
                            <td>${m[1]}</td><td class="text-center">${m[2]}</td>
                            <td class="text-end money"><fmt:formatNumber value="${m[3]}" pattern="#,##0"/>đ</td>
                            <td class="text-center"><span class="badge ${m[5] == 'Đã ra' ? 'text-bg-success' : 'text-bg-secondary'}">${m[5]}</span></td>
                            <td class="text-end money"><strong><fmt:formatNumber value="${m[4]}" pattern="#,##0"/>đ</strong></td>
                        </tr>
                        <c:if test="${m[5] == 'Chưa ra' && hoaDon[5] == 'Chưa thanh toán'}">
                            <tr class="no-print" data-action-state="waiting"><td colspan="5" class="text-end pt-0"><form method="post" action="${pageContext.request.contextPath}/hoa-don" class="d-inline"><input type="hidden" name="action" value="da-ra"><input type="hidden" name="id" value="${hoaDon[0]}"><input type="hidden" name="ctId" value="${m[0]}"><button class="btn btn-sm btn-outline-success">Xác nhận món đã ra</button></form></td></tr>
                        </c:if>
                    </c:forEach>
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-between border-top pt-3 fs-5"><strong>Tổng thanh toán</strong><strong class="money"><fmt:formatNumber value="${tongThanhToan}" pattern="#,##0"/>đ</strong></div>
            <c:if test="${hoaDon[5] == 'Chưa thanh toán'}">
                <div class="text-center mt-4 no-print">
                    <c:if test="${cheDoThanhToan}">
                        <div class="border rounded-3 p-3 mb-3">
                            <h6>QR thanh toán</h6>
                            <c:choose>
                                <c:when test="${not empty qrUrl}">
                                    <img class="qr" alt="QR chuyển khoản ngân hàng" src="${qrUrl}">
                                    <div class="small text-muted mt-2">Quét mã để chuyển đúng số tiền và nội dung hóa đơn.</div>
                                </c:when>
                                <c:otherwise>
                                    <div class="alert alert-warning mb-0">Chưa cấu hình tài khoản nhận tiền. Hãy thiết lập các biến môi trường VIETQR_BANK_BIN, VIETQR_ACCOUNT_NO và VIETQR_ACCOUNT_NAME để tạo QR chuyển khoản thật.</div>
                                </c:otherwise>
                            </c:choose>
                        </div>
                        <form method="post" action="${pageContext.request.contextPath}/hoa-don" onsubmit="return confirm('Xác nhận khách đã thanh toán hóa đơn này?')">
                            <input type="hidden" name="action" value="xac-nhan-thanh-toan"><input type="hidden" name="id" value="${hoaDon[0]}">
                            <button class="btn btn-success btn-lg">Đã nhận thanh toán</button>
                        </form>
                    </c:if>
                    <c:if test="${not cheDoThanhToan}">
                        <form method="get" action="${pageContext.request.contextPath}/hoa-don" class="d-inline"><input type="hidden" name="action" value="thanh-toan"><input type="hidden" name="id" value="${hoaDon[0]}"><button class="btn btn-primary">Trả khách / Thanh toán</button></form>
                    </c:if>
                </div>
            </c:if>
        </div>
    </c:when>
    <c:otherwise>
        <div class="d-flex justify-content-between align-items-center mb-4"><div><h2 class="fw-bold mb-1">Quản lý hóa đơn</h2><div class="text-muted">Theo dõi hóa đơn tại các bàn và lịch sử thanh toán</div></div><a href="${pageContext.request.contextPath}/ban" class="btn btn-outline-secondary">Quản lý bàn</a></div>
        <div class="panel mb-4">
            <h5 class="mb-3">🟠 Hóa đơn chưa thanh toán <span class="badge text-bg-warning">${dsChuaThanhToan.size()}</span></h5>
            <div class="table-responsive"><table class="table table-hover align-middle"><thead><tr><th>Mã hóa đơn</th><th>Bàn</th><th>Ngày lập</th><th class="text-end">Tạm tính</th><th>Trạng thái</th><th></th></tr></thead><tbody>
            <c:forEach items="${dsChuaThanhToan}" var="hd"><tr><td>#${hd[0]}</td><td>${hd[1]}</td><td>${hd[2]}</td><td class="text-end money"><fmt:formatNumber value="${hd[3]}" pattern="#,##0"/>đ</td><td><span class="badge text-bg-warning">${hd[4]}</span></td><td class="text-end"><a class="btn btn-sm btn-outline-primary" href="${pageContext.request.contextPath}/hoa-don?action=chi-tiet&id=${hd[0]}">Xem / Đã ra</a> <a class="btn btn-sm btn-primary" href="${pageContext.request.contextPath}/hoa-don?action=thanh-toan&id=${hd[0]}">Trả khách</a></td></tr></c:forEach>
            <c:if test="${empty dsChuaThanhToan}"><tr><td colspan="6" class="text-center text-muted py-4">Hiện không có bàn nào cần thanh toán.</td></tr></c:if>
            </tbody></table></div>
        </div>
        <div class="panel">
            <h5 class="mb-3">🟢 Hóa đơn đã thanh toán <span class="badge text-bg-success">${dsDaThanhToan.size()}</span></h5>
            <div class="table-responsive"><table class="table table-hover align-middle"><thead><tr><th>Mã hóa đơn</th><th>Bàn</th><th>Ngày lập</th><th class="text-end">Tổng tiền</th><th>Trạng thái</th><th></th></tr></thead><tbody>
            <c:forEach items="${dsDaThanhToan}" var="hd"><tr><td>#${hd[0]}</td><td>${hd[1]}</td><td>${hd[2]}</td><td class="text-end money"><fmt:formatNumber value="${hd[3]}" pattern="#,##0"/>đ</td><td><span class="badge text-bg-success">${hd[4]}</span></td><td class="text-end"><a class="btn btn-sm btn-outline-dark" href="${pageContext.request.contextPath}/hoa-don?action=chi-tiet&id=${hd[0]}">Xem / In</a></td></tr></c:forEach>
            <c:if test="${empty dsDaThanhToan}"><tr><td colspan="6" class="text-center text-muted py-4">Chưa có hóa đơn đã thanh toán.</td></tr></c:if>
            </tbody></table></div>
        </div>
    </c:otherwise>
</c:choose>
</div>
    </div>
</div>
<script>
function locMon(state){
  document.querySelectorAll('[data-mon-state]').forEach(function(row){
    row.style.display = state === 'all' || row.dataset.monState === state ? '' : 'none';
  });
  document.querySelectorAll('[data-action-state]').forEach(function(row){
    row.style.display = state === 'all' || state === 'waiting' ? '' : 'none';
  });
}
window.addEventListener('beforeprint', function(){ locMon('all'); });
</script>
</body></html>
